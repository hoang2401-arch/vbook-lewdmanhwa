load('common.js');
function gtNumber(url) {
 var m=String(url).match(/\/chuong-([\d]+(?:[.\-][\d]+)*)$/i);return m?m[1]:'';
}
function gtChapters(doc,book) {
 var data=[],seen={};if(!doc)return data;
 var a=doc.select('a[href*="/chuong-"]');
 for(var i=0;i<a.size();i++){
   var u=gtChapUrl(a.get(i).attr('href'),book),n=gtNumber(u);
   if(!n||u.indexOf(book+'/chuong-')!==0||seen[u])continue;
   seen[u]=1;
   var label=gtClean(a.get(i).text());
   // Reader selector uses labels '422'; chapter detail uses '#422 time views'.
   var numeric=(label.match(/(?:#|Chương\s*)?\s*(\d+(?:[.\-]\d+)*)/i)||[])[1];
   data.push({name:'Chương '+(numeric===n?numeric:n),url:u});
 }
 return data;
}
function gtMerge(dst,src){var seen={};for(var i=0;i<dst.length;i++)seen[dst[i].url]=1;for(var j=0;j<src.length;j++)if(!seen[src[j].url]){seen[src[j].url]=1;dst.push(src[j]);}}
function gtSort(items){items.sort(function(a,b){var x=gtNumber(a.url).split(/[.\-]/),y=gtNumber(b.url).split(/[.\-]/),n=Math.max(x.length,y.length);for(var i=0;i<n;i++){var d=Number(x[i]||0)-Number(y[i]||0);if(d)return d;}return 0;});}
function gtExpected(doc) {
 var t=gtText(doc,'body'),m=t.match(/(\d{1,5})\s*Chương/i);
 return m?parseInt(m[1],10):0;
}
function execute(url) {
 var book=gtBookUrl(url,GT_BASE+'/');
 if(!book)return Response.error('URL truyện không hợp lệ');
 var chapters=[],source=null,expected=0;
 try{source=gtGet(book);expected=gtExpected(source);gtMerge(chapters,gtChapters(source,book));}
 catch(e){gtLog('detail toc HTTP: '+String(e));}
 // Crucial: chapter reader contains full chapter selector even when detail shows 20.
 if(chapters.length)gtSort(chapters);
 var newest=chapters.length?chapters[chapters.length-1].url:'';
 if(newest) {
   try {var rd=gtGet(newest);gtMerge(chapters,gtChapters(rd,book));}
   catch(e){gtLog('reader menu HTTP: '+String(e));}
 }
 // Fallback for SPA / collapsed chapter list; click "Hiển thị tất cả".
 if(!chapters.length||chapters.length<expected) {
   var browser=null;
   try {
     browser=gtBrowserOpen(book,gtExpandTocJS(),1300);
     gtMerge(chapters,gtChapters(browser.html(),book));
     if(!newest&&chapters.length){gtSort(chapters);newest=chapters[chapters.length-1].url;}
   }catch(e){gtLog('browser toc: '+String(e));}
   finally{if(browser)try{browser.close();}catch(e){}}
 }
 if(newest&&(!expected||chapters.length<expected)){
   var browser2=null;
   try{browser2=gtBrowserOpen(newest,'',1000);gtMerge(chapters,gtChapters(browser2.html(),book));}
   catch(e){gtLog('browser reader selector: '+String(e));}
   finally{if(browser2)try{browser2.close();}catch(e){}}
 }
 if(!chapters.length)return Response.error('Không tìm thấy mục lục');
 gtSort(chapters);
 gtLog('TOC '+book+' got='+chapters.length+' expected='+(expected||'?'));
 // Avoid fabricating missing URLs. If result is partial, it remains partial and logged.
 return Response.success(chapters);
}
function gtExpandTocJS(){return '(function(){var btns=document.querySelectorAll("button");for(var i=0;i<btns.length;i++){if(/hiển thị tất cả|show all/i.test(btns[i].textContent||""))btns[i].click();}})();';}
