load('common.js');
function execute(url) {
 var target=gtBookUrl(url,GT_BASE+'/');
 if(!target)return Response.error('URL truyện không hợp lệ');
 var doc=null,error='';
 try{doc=gtGet(target);}catch(e){error=String(e);}
 if(!doc&&typeof Engine!=='undefined') {
   var browser=null;
   try{browser=gtBrowserOpen(target,'',1000);doc=browser.html();}
   catch(e){error+='; '+String(e);}
   finally{if(browser)try{browser.close();}catch(e){}}
 }
 if(!doc)return Response.error('Không tải được thông tin: '+error);
 var title=gtText(doc,'h1')||gtAttr(doc,'meta[property="og:title"]','content')||gtAttr(doc,'meta[name="twitter:title"]','content');
 title=gtClean(title).replace(/\s*\[Tới Chương.*$/i,'');
 var cover=gtAbs(gtAttr(doc,'meta[property="og:image"]','content'),target);
 if(!cover)cover=gtImg(gtFirst(doc,'img[alt],.cover img,[class*=cover] img'),target);
 var description=gtText(doc,'[class*=summary],[class*=description],[class*=synopsis],[class*=introduce]')||gtAttr(doc,'meta[name="description"]','content');
 // Ignore the generic HTML metadata if possible.
 if(description.length>4000)description=description.substr(0,4000);
 var body=gtText(doc,'body');
 var author=gtText(doc,'[class*=author]');
 if(!author) {var am=body.match(/Tác giả:\s*([^\n]{2,70}?)(?:\s+Trạng thái:|$)/i);if(am)author=gtClean(am[1]);}
 var ongoing=!/Trạng thái:\s*(?:Hoàn thành|Đã hoàn thành)/i.test(body);
 if(!title)return Response.error('Không tìm thấy tên truyện trong HTML');
 return Response.success({name:title,cover:cover,host:GT_BASE,author:author||'Đang cập nhật',description:description,detail:description,ongoing:ongoing});
}
