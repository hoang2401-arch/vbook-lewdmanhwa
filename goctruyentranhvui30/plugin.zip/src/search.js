load('common.js');
function execute(key,page) {
 var keyword=gtClean(key),num=page?parseInt(page,10):1;
 if(!keyword||!num||num<1||num>30)return Response.success([],null);
 // /danh-sach result area is client-rendered and may not support a stable URL filter.
 var url=GT_BASE+'/danh-sach?keyword='+encodeURIComponent(keyword)+'&page='+num;
 var browser=null,items=[],errors=[];
 try {
   browser=gtBrowserOpen(url,gtSearchUI(keyword),1800);
   items=gtBooks(browser.html(),url);
   // Some layouts require an additional render tick.
   if(!items.length) {
     browser.callJs(gtDecorateCardsJS(),1100);
     items=gtBooks(browser.html(),url);
   }
 }catch(e){errors.push(String(e));}
 finally{if(browser)try{browser.close();}catch(e){}}
 if(!items.length&&num===1)return Response.error('Không tìm thấy/truy cập được kết quả tìm kiếm: '+errors.join('; '));
 return Response.success(items,items.length>=16?String(num+1):null);
}
function gtSearchUI(keyword) {
 return '(function(){'+
  'var key='+JSON.stringify(keyword)+';'+
  'var fields=document.querySelectorAll("input");var input=null;'+
  'for(var i=0;i<fields.length;i++){var p=(fields[i].placeholder||"").toLowerCase();if(p.indexOf("nhập từ khóa")>=0||p.indexOf("tìm kiếm")>=0){input=fields[i];break;}}'+
  'if(input){'+
  'var setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value");'+
  'if(setter&&setter.set)setter.set.call(input,key);else input.value=key;'+
  'input.dispatchEvent(new Event("input",{bubbles:true}));input.dispatchEvent(new Event("change",{bubbles:true}));'+
  'var b=Array.from(document.querySelectorAll("button")).filter(function(x){return /tìm kiếm/i.test(x.textContent||"");})[0];'+
  'if(b)b.click();else input.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",bubbles:true}));'+
  '}'+
  gtDecorateCardsJS().replace(/^\(function\(\)\{/,'').replace(/\}\)\(\);$/,'')+
 '})();';
}
