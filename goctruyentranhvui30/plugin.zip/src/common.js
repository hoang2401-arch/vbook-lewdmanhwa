// VBook extension for goctruyentranhvui30.com; JavaScript ES5 compatible.
// Use only documented VBook API on the extension side: select/get/size/text/attr.
var GT_BASE = 'https://goctruyentranhvui30.com';
function gtClean(s) { return String(s == null ? '' : s).replace(/\s+/g,' ').trim(); }
function gtAbs(value, context) {
  var s=gtClean(value).replace(/&amp;/g,'&');
  if (!s || /^(data:|blob:|javascript:|about:|#)/i.test(s)) return '';
  if (/^https?:\/\//i.test(s)) return s;
  if (s.indexOf('//')===0) return 'https:'+s;
  if (s.charAt(0)==='/') return GT_BASE+s;
  var base=String(context||GT_BASE+'/').replace(/[?#].*$/,'');
  if (s.charAt(0)==='?') return base+s;
  return base.replace(/\/[^/]*$/,'/')+s;
}
function gtFirst(doc,selector) {
  if(!doc) return null;
  var nodes=doc.select(selector);
  return nodes && nodes.size()>0 ? nodes.get(0) : null;
}
function gtText(doc,selector) {var el=gtFirst(doc,selector);return el?gtClean(el.text()):'';}
function gtAttr(doc,selector,attr) {var el=gtFirst(doc,selector);return el?gtClean(el.attr(attr)):'';}
function gtBookUrl(href,context) {
  var u=gtAbs(href,context);
  var m=u.match(/^https?:\/\/goctruyentranhvui30\.com\/truyen\/([^\/?#]+)(?:[?#].*)?\/?$/i);
  return m ? GT_BASE+'/truyen/'+m[1] : '';
}
function gtChapUrl(href,context) {
  var u=gtAbs(href,context);
  var m=u.match(/^https?:\/\/goctruyentranhvui30\.com\/truyen\/([^\/?#]+)\/chuong-([\w.\-]+)(?:[?#].*)?\/?$/i);
  return m ? GT_BASE+'/truyen/'+m[1]+'/chuong-'+m[2] : '';
}
function gtGet(url) {
  var r=fetch(url,{headers:{'Referer':GT_BASE+'/','Accept':'text/html,application/xhtml+xml'}});
  if(!r.ok) throw new Error('HTTP '+r.status+' '+url);
  return r.html();
}
function gtLog(message) {try{if(typeof Console!=='undefined') Console.log('GocTruyen v2: '+message);}catch(e){}}
function gtImg(element,context) {
  if(!element) return '';
  var attrs=['data-vbook-img','data-src','data-original','data-lazy-src','data-url','src','content'];
  for(var j=0;j<attrs.length;j++) {
    var val=gtClean(element.attr(attrs[j]));
    if(!val) continue;
    var url=gtAbs(val,context);
    if(/^https?:\/\//i.test(url) && !/\/(?:nocover|placeholder|loading)[^/]*\./i.test(url)) return url;
  }
  var srcset=gtClean(element.attr('data-srcset')||element.attr('srcset'));
  if(srcset) return gtAbs(srcset.split(',')[0].trim().split(/\s+/)[0],context);
  return '';
}
// Ignore navigation controls, banners and image paths masquerading as book titles.
function gtValidName(raw) {
 var name=gtClean(raw).replace(/\s*(?:#\s*Chương|Chương)\s*\d+(?:[.,]\d+)?\s*.*$/i,'').trim();
 if(!name||name.length<4||name.length>125) return '';
 if(/^(?:\/|https?:|image\/|img\/|banner\/)/i.test(name))return '';
 if(/\.(?:png|jpe?g|webp|gif|svg)(?:[?#]|$)/i.test(name))return '';
 if(/^(?:Truyện Theo Dõi|Truyện Đã Đọc|Theo Dõi|Đã Đọc|Danh Sách|Tìm Kiếm|Đọc Truyện|Trang Chủ|Xem Thêm|Trước|Sau|Thể Loại|Truyện Mới)$/i.test(name))return '';
 if(/^\d[\d,\. ]*$/.test(name)||/(?:\/image\/banner\/|\/uploads\/banner\/)/i.test(name))return '';
 return name;
}
function gtBookTitle(anchor) {
 var titleEl=gtFirst(anchor,'h2,h3,h4,[class*=book-title],[class*=manga-title],[class*=comic-title]');
 var name=titleEl?gtValidName(titleEl.text()):'';
 if(!name)name=gtValidName(anchor.attr('title')||anchor.attr('aria-label'));
 if(!name){var img=gtFirst(anchor,'img[alt]');if(img)name=gtValidName(img.attr('alt'));}
 if(!name)name=gtValidName(anchor.text());
 return name;
}
function gtBooks(doc,context) {
 var data=[],seen={}; if(!doc)return data;
 var normalized=doc.select('[data-vbook-book]');
 for(var k=0;k<normalized.size();k++){
  var e=normalized.get(k),link=gtBookUrl(e.attr('data-vbook-book'),context);
  var name=gtValidName(e.attr('data-vbook-name'));
  if(!link||!name||seen[link])continue;
  var cover=gtAbs(e.attr('data-vbook-cover'),context);
  if(/\/image\/banner\//i.test(cover))continue;
  seen[link]=1;
  data.push({name:name,link:link,cover:cover,description:gtClean(e.attr('data-vbook-chapter'))});
 }
 var links=doc.select('a[href*="/truyen/"]');
 for(var i=0;i<links.size();i++){
  var a=links.get(i),link=gtBookUrl(a.attr('href'),context);
  if(!link||seen[link])continue;
  var name=gtBookTitle(a),img=gtFirst(a,'img');
  var cover=gtImg(img,context);
  if(!name||/\/image\/banner\//i.test(cover))continue;
  // Require a plausible title, not a user-library or UI control link.
  seen[link]=1;
  data.push({name:name,link:link,cover:cover,description:''});
 }
 return data;
}
// Runs in the site's web browser (NOT inside the vBook script interpreter).
function gtDecorateCardsJS() {
 return '(function(){'+
  'if(!window.__vbookCards)window.__vbookCards={};'+
  'var ls=document.querySelectorAll("a[href*=\\"/truyen/\\"]");'+
  'for(var i=0;i<ls.length;i++){var a=ls[i],u="";'+
  'try{u=new URL(a.getAttribute("href"),location.href).href;}catch(e){}'+
  'if(!/^https?:\\/\\/goctruyentranhvui30\\.com\\/truyen\\/[^/]+\\/?(?:[?#].*)?$/i.test(u))continue;'+
  'if(a.closest&&a.closest("header,nav,footer,[role=navigation]"))continue;'+
  'var node=a,img=a.querySelector("img"),title=a.querySelector("h2,h3,h4");'+
  'for(var d=0;d<4&&node&&!title;d++,node=node.parentElement){'+
  ' title=node.querySelector("h2,h3,h4");if(!img)img=node.querySelector("img");'+
  ' if(node.tagName==="MAIN"||node.tagName==="BODY")break;}'+
  'var name=((title&&title.textContent)||a.getAttribute("title")||a.getAttribute("aria-label")||'+
  ' (img&&img.getAttribute("alt"))||a.textContent||"").trim();'+
  'name=name.replace(/^\\s*[\\d,.]+\\s*/,"").replace(/\\s*(?:#\\s*Chương|Chương)\\s*\\d+.*$/i,"").trim();'+
  'if(!name||name.length<4||name.length>125||/^(?:\\/|https?:|image\\/|img\\/)/i.test(name)||'+
  ' /\\.(?:png|jpg|jpeg|webp|svg)(?:[?#]|$)/i.test(name)||'+
  ' /^(?:Truyện Theo Dõi|Truyện Đã Đọc|Theo Dõi|Đã Đọc|Trang Chủ)$/i.test(name))continue;'+
  'var cover=img?(img.getAttribute("data-src")||img.getAttribute("data-original")||img.currentSrc||img.getAttribute("src")||""):"";'+
  'if(/\\/image\\/banner\\//i.test(cover))continue;'+
  'if(cover)try{cover=new URL(cover,location.href).href;}catch(e){}'+
  'var n=node||a,ch=(n.textContent||"").match(/(?:#\\s*)?Chương\\s*\\d+(?:[.,]\\d+)?/i);'+
  'var key=u+"|"+name;if(window.__vbookCards[key])continue;window.__vbookCards[key]=1;'+
  'var el=document.createElement("span");el.style.display="none";'+
  'el.setAttribute("data-vbook-book",u);el.setAttribute("data-vbook-name",name);'+
  'el.setAttribute("data-vbook-cover",cover);el.setAttribute("data-vbook-chapter",ch?ch[0]:"");'+
  'document.body.appendChild(el);'+
  '}'+
 '})();';
}
function gtBrowserOpen(url,js,wait) {
 var browser=Engine.newBrowser();
 browser.launch(url,22000);
 if(js)browser.callJs(js,wait||850);
 return browser;
}
