// VBook extension for goctruyentranhvui30.com; JavaScript ES5 compatible.
// Use only documented VBook API on the extension side: select/get/size/text/attr.
var GT_BASE = 'https://goctruyentranhvui30.com';
function gtClean(s) { return String(s == null ? '' : s).replace(/\s+/g,' ').trim(); }
function gtAbs(value, context) {
  var s=gtClean(value).replace(/&amp;/g,'&');
  if (!s || /^(data:|blob:|javascript:|about:|#)/i.test(s)) return '';
  if (/^https?:\/\//i.test(s)) return s;
  if (s.indexOf('//')===0) return 'https:'+s;
  if (s.charAt(0)==='/') return GT_BASE+s;
  var base=String(context||GT_BASE+'/').replace(/[?#].*$/,'');
  if (s.charAt(0)==='?') return base+s;
  return base.replace(/\/[^/]*$/,'/')+s;
}
function gtFirst(doc,selector) {
  if(!doc) return null;
  var nodes=doc.select(selector);
  return nodes && nodes.size()>0 ? nodes.get(0) : null;
}
function gtText(doc,selector) {var el=gtFirst(doc,selector);return el?gtClean(el.text()):'';}
function gtAttr(doc,selector,attr) {var el=gtFirst(doc,selector);return el?gtClean(el.attr(attr)):'';}
function gtBookUrl(href,context) {
  var u=gtAbs(href,context);
  var m=u.match(/^https?:\/\/goctruyentranhvui30\.com\/truyen\/([^\/?#]+)(?:[?#].*)?\/?$/i);
  return m ? GT_BASE+'/truyen/'+m[1] : '';
}
function gtChapUrl(href,context) {
  var u=gtAbs(href,context);
  var m=u.match(/^https?:\/\/goctruyentranhvui30\.com\/truyen\/([^\/?#]+)\/chuong-([\w.\-]+)(?:[?#].*)?\/?$/i);
  return m ? GT_BASE+'/truyen/'+m[1]+'/chuong-'+m[2] : '';
}
function gtGet(url) {
  var r=fetch(url,{headers:{'Referer':GT_BASE+'/','Accept':'text/html,application/xhtml+xml'}});
  if(!r.ok) throw new Error('HTTP '+r.status+' '+url);
  return r.html();
}
function gtLog(message) {try{if(typeof Console!=='undefined') Console.log('GocTruyen v1: '+message);}catch(e){}}
function gtImg(element,context) {
  if(!element) return '';
  var attrs=['data-vbook-img','data-src','data-original','data-lazy-src','data-url','src','content'];
  for(var j=0;j<attrs.length;j++) {
    var val=gtClean(element.attr(attrs[j]));
    if(!val) continue;
    var url=gtAbs(val,context);
    if(/^https?:\/\//i.test(url) && !/\/(?:nocover|placeholder|loading)[^/]*\./i.test(url)) return url;
  }
  var srcset=gtClean(element.attr('data-srcset')||element.attr('srcset'));
  if(srcset) return gtAbs(srcset.split(',')[0].trim().split(/\s+/)[0],context);
  return '';
}
function gtBookTitle(anchor) {
  var name=gtClean(anchor.attr('title')||anchor.attr('aria-label'));
  var img=gtFirst(anchor,'img[alt]');
  if(!name&&img) name=gtClean(img.attr('alt'));
  if(!name) {
    var n=gtFirst(anchor,'h2,h3,h4,[class*=title]');
    if(n) name=gtClean(n.text());
  }
  if(!name) name=gtClean(anchor.text()).replace(/^\d[\d,.\s]+/,'').trim();
  return name.replace(/\s*(?:#\s*Chương|Chương)\s*\d+(?:[.,]\d+)?\s*.*$/i,'').trim();
}
// Prefer normalized links inserted by website-side JS. Fallback works on SSR.
function gtBooks(doc,context) {
  var data=[],seen={};
  var normalized=doc.select('[data-vbook-book]');
  for(var k=0;k<normalized.size();k++) {
    var e=normalized.get(k),link=gtBookUrl(e.attr('data-vbook-book'),context);
    if(!link||seen[link])continue;
    var name=gtClean(e.attr('data-vbook-name'));
    if(!name)continue;
    seen[link]=1;
    data.push({name:name,link:link,cover:gtAbs(e.attr('data-vbook-cover'),context),description:gtClean(e.attr('data-vbook-chapter'))});
  }
  var links=doc.select('a[href*="/truyen/"]');
  for(var i=0;i<links.size();i++) {
    var a=links.get(i),book=gtBookUrl(a.attr('href'),context);
    if(!book||seen[book])continue;
    var name=gtBookTitle(a),img=gtFirst(a,'img');
    var cover=gtImg(img,context);
    if (!name || name.length>110 || /^\d+[\d., ]*$/.test(name)) continue;
    seen[book]=1;
    data.push({name:name,link:book,cover:cover,description:''});
  }
  return data;
}
// This runs IN the site browser: standard browser DOM traversal is allowed here.
// It adds normalized nodes; VBook's extension runtime only reads those nodes via select().
function gtDecorateCardsJS() {
 return '(function(){'+
  'if(!window.__vbookCards)window.__vbookCards={};'+
  'var ls=document.querySelectorAll("a[href*=\\"/truyen/\\"]");'+
  'for(var i=0;i<ls.length;i++){var a=ls[i],u="";try{u=new URL(a.getAttribute("href"),location.href).href;}catch(e){}'+
  'if(!/^https?:\\/\\/goctruyentranhvui30\\.com\\/truyen\\/[^/]+\\/?(?:[?#].*)?$/i.test(u)||window.__vbookCards[u])continue;'+
  'var node=a,im=null;for(var k=0;k<5&&node;k++,node=node.parentElement){'+
  ' if(!im)im=node.querySelector("img");'+
  ' if(im&&((node.querySelector("h2,h3,h4")||{}).textContent||a.textContent||"").trim())break;}'+
  'var name=(a.getAttribute("title")||a.getAttribute("aria-label")||((im||{}).getAttribute?im.getAttribute("alt"):"")||a.textContent||"").trim();'+
  'name=name.replace(/^\\s*[\\d,.]+\\s*/,"").replace(/\\s*(?:#\\s*Chương|Chương)\\s*\\d+.*$/i,"").trim();'+
  'if(!name||name.length>110)continue;'+
  'var cover=im?(im.getAttribute("data-src")||im.getAttribute("data-original")||im.currentSrc||im.src||""):"";'+
  'if(cover)try{cover=new URL(cover,location.href).href;}catch(e){}'+
  'var ch=(node&&node.textContent||"").match(/(?:#\\s*)?Chương\\s*\\d+(?:[.,]\\d+)?/i);'+
  'var entry=document.createElement("span");entry.setAttribute("data-vbook-book",u);entry.setAttribute("data-vbook-name",name);entry.setAttribute("data-vbook-cover",cover);entry.setAttribute("data-vbook-chapter",ch?ch[0]:"");'+
  'entry.style.display="none";document.body.appendChild(entry);window.__vbookCards[u]=true;'+
  '}'+
 '})();';
}
function gtBrowserOpen(url,js,wait) {
 var browser=Engine.newBrowser();
 browser.launch(url,22000);
 if(js)browser.callJs(js,wait||850);
 return browser;
}
