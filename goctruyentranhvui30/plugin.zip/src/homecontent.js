load('common.js');
function execute(url,page) {
 var base=gtAbs(url,GT_BASE+'/'),current=page?parseInt(page,10):1;
 if(!current||current<1||current>200)return Response.success([],null);
 // This site's /danh-sach is JS-rendered: browser is required even on page 1.
 var target=current===1?base:base+(base.indexOf('?')>=0?'&':'?')+'page='+current;
 var result=[],browser=null,error='';
 try {
   if(base.indexOf('/trang-chu')>=0)result=gtBooks(gtGet(base),base);
 }catch(e){error=String(e);}
 if(base.indexOf('/danh-sach')>=0||!result.length||!result[0].cover) {
   try {
     browser=gtBrowserOpen(target,gtDecorateCardsJS(),1700);
     var loaded=gtBooks(browser.html(),target);
     if(loaded.length)result=loaded;
     for(var k=0; k<5 && !result.length;k++) {
       browser.callJs('window.scrollBy(0,700);',1000);
       browser.callJs(gtDecorateCardsJS(),650);
       var retry=gtBooks(browser.html(),target);
       if(retry.length)result=retry;
     }
   }catch(e){error+=' '+String(e);}
   finally{if(browser)try{browser.close();}catch(e){}}
 }
 if(!result.length && current===1) return Response.error('Danh sách chưa tải được. '+error);
 // Avoid infinite pagination if backend keeps returning the same first page.
 var next=(base.indexOf('/trang-chu')>=0)?null:((result.length>=16&&current<30)?String(current+1):null);
 gtLog('home '+base+' page='+current+' books='+result.length);
 return Response.success(result,next);
}
