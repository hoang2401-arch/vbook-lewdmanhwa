load('common.js');
function gtHasChapter(items){for(var i=0;i<items.length;i++)if(items[i].description)return true;return false;}
function execute(url,page) {
 var base=gtAbs(url,GT_BASE+'/'),current=page?parseInt(page,10):1;
 if(!current||current<1||current>100)return Response.success([],null);
 var latest=base.indexOf('/truyen-cap-nhat')>=0;
 var homepage=base.indexOf('/trang-chu')>=0;
 var target=latest?GT_BASE+'/truyen-cap-nhat?p='+current:
       (homepage?base:(base+(base.indexOf('?')>=0?'&':'?')+'page='+current));
 var result=[],browser=null,error='';
 try {result=gtBooks(gtGet(target),target);}catch(e){error=String(e);}
 // Browser enrichment is needed EVEN WHEN HTTP finds books: SSR frequently omits
 // the latest-chapter label or places it in a sibling node outside the book link.
 // Preserve good HTTP results if the website's JS fails to load.
 var enrich=!result.length;
 if(!enrich) {
  for(var n=0;n<result.length;n++){if(!result[n].description){enrich=true;break;}}
 }
 if(enrich) {
  try {
   browser=gtBrowserOpen(target,gtDecorateCardsJS(),1450);
   var extra=gtBooks(browser.html(),target);
   for(var i=0;i<4&&(!extra.length||!gtHasChapter(extra));i++) {
    browser.callJs('window.scrollBy(0,700);',500);
    browser.callJs(gtDecorateCardsJS(),450);
    extra=gtBooks(browser.html(),target);
   }
   if(!result.length)result=extra;
   else {
    var index={};
    for(var j=0;j<result.length;j++)index[result[j].link]=j;
    for(var k=0;k<extra.length;k++){
     var b=extra[k],ix=index[b.link];
     if(ix!==undefined){
      if(b.description)result[ix].description=b.description;
      if(!result[ix].cover&&b.cover)result[ix].cover=b.cover;
     }
    }
   }
  } catch(e){error+='; browser: '+String(e);}
  finally{if(browser)try{browser.close();}catch(e){}}
 }
 if(!result.length&&current===1)return Response.error('Không lấy được danh sách truyện: '+error);
 // Do not infer pagination on the home page. /truyen-cap-nhat?page= is documented.
 var next=homepage?null:(result.length>=12&&current<35?String(current+1):null);
 gtLog('home '+target+' books='+result.length);
 return Response.success(result,next);
}
