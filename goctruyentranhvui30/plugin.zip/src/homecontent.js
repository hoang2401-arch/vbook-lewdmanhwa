load('common.js');
function execute(url,page) {
 var base=gtAbs(url,GT_BASE+'/'),current=page?parseInt(page,10):1;
 if(!current||current<1||current>100)return Response.success([],null);
 var latest=base.indexOf('/truyen-cap-nhat')>=0;
 var homepage=base.indexOf('/trang-chu')>=0;
 var target=latest?GT_BASE+'/truyen-cap-nhat?p='+current:
       (homepage?base:(base+(base.indexOf('?')>=0?'&':'?')+'page='+current));
 var result=[],browser=null,error='';
 try {result=gtBooks(gtGet(target),target);}catch(e){error=String(e);}
 // Only use a browser when the server output has no usable books.
 if(!result.length) {
  try {
   browser=gtBrowserOpen(target,gtDecorateCardsJS(),1400);
   result=gtBooks(browser.html(),target);
   for(var i=0;i<3&&!result.length;i++) {
    browser.callJs('window.scrollBy(0,650);',650);
    browser.callJs(gtDecorateCardsJS(),600);
    result=gtBooks(browser.html(),target);
   }
  } catch(e){error+='; '+String(e);}
  finally{if(browser)try{browser.close();}catch(e){}}
 }
 if(!result.length&&current===1)return Response.error('Không lấy được danh sách truyện: '+error);
 // Do not infer pagination on the home page. /truyen-cap-nhat?page= is documented.
 var next=homepage?null:(result.length>=12&&current<35?String(current+1):null);
 gtLog('home '+target+' books='+result.length);
 return Response.success(result,next);
}
