function execute() {
  return Response.success([
    {title:'Mới cập nhật',input:'https://goctruyentranhvui30.com/truyen-cap-nhat',script:'homecontent.js'},
    {title:'Tất cả',input:'https://goctruyentranhvui30.com/danh-sach',script:'homecontent.js'},
    {title:'Hành động',input:'https://goctruyentranhvui30.com/danh-sach?category=ACT',script:'homecontent.js'},
    {title:'Manhwa',input:'https://goctruyentranhvui30.com/danh-sach?category=MAW',script:'homecontent.js'},
    {title:'Manhua',input:'https://goctruyentranhvui30.com/danh-sach?category=MAU',script:'homecontent.js'},
    {title:'Drama',input:'https://goctruyentranhvui30.com/danh-sach?category=DRA',script:'homecontent.js'},
    {title:'Huyền bí',input:'https://goctruyentranhvui30.com/danh-sach?category=MYS',script:'homecontent.js'},
    {title:'Học đường',input:'https://goctruyentranhvui30.com/danh-sach?category=SCL',script:'homecontent.js'}
  ]);
}
