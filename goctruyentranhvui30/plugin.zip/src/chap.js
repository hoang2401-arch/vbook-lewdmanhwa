load('common.js');
// This website can populate reader images only after executing JS and scrolling.
// Track images across all scroll steps (including virtualized/lazy-loaded pages).
function gtReaderAction(mode) {
 var script=[
 '(function(){',
 'var store=window.__vbookReaderStore||(window.__vbookReaderStore={pages:[],seen:{},steps:0,bottom:0});',
 'function collect(){',
 ' var imgs=document.querySelectorAll("img, picture source");',
 ' for(var i=0;i<imgs.length;i++){',
 '  var im=imgs[i],src=im.getAttribute("data-src")||im.getAttribute("data-original")||im.getAttribute("data-lazy-src")||im.getAttribute("srcset")||im.currentSrc||im.getAttribute("src")||"";',
 '  if(!src||/^(?:data:|blob:)/i.test(src))continue;',
 '  if(src.indexOf(",")>0)src=src.split(",")[0];src=src.trim().split(/\s+/)[0];  var u="";try{u=new URL(src,location.href).href;}catch(e){continue;}',
 '  if(!/^https?:/i.test(u)||/\\.(?:svg|ico)(?:[?#]|$)/i.test(u)||/(?:avatar|icon|logo|banner|captcha|ads?banner)/i.test(u))continue;',
 '  var w=im.naturalWidth||im.width||im.clientWidth||0,h=im.naturalHeight||im.height||im.clientHeight||0;',
 '  var p=im.parentElement,reader=false;',
 '  for(var d=0;d<6&&p;d++,p=p.parentElement){',
 '   if(/(?:reader|reading|chapter|comic|manga|page-image|image-content|viewer|content-page|truyen)/i.test(String(p.id||"")+" "+String(p.className||""))){reader=true;break;}',
 '  }',
 '  var isImage=/\\.(?:jpe?g|png|webp|avif|gif)(?:[?#]|$)/i.test(u)||/\\/_next\\/image\\?/i.test(u);',
 '  if(!isImage)continue;',
 '  if(!reader && !(w>=250&&h>=300))continue;',
 '  var k=u.replace(/[?#].*$/,""),role=String(im.className||"")+" "+String(im.alt||"");',
 '  if(/(?:cover|thumbnail|thumb|avatar|logo)/i.test(role)&&!reader)continue;',
 '  if(!store.seen[k]){store.seen[k]=true;store.pages.push(u);}',
 ' }',
 ' var holder=document.getElementById("vbook-reader-captured");',
 ' if(!holder){holder=document.createElement("div");holder.id="vbook-reader-captured";holder.style.display="none";document.body.appendChild(holder);}',
 ' while(holder.firstChild)holder.removeChild(holder.firstChild);',
 ' for(var j=0;j<store.pages.length;j++){var el=document.createElement("i");el.setAttribute("data-vbook-page",store.pages[j]);holder.appendChild(el);}',
 '}',
 'collect();',
 'if('+JSON.stringify(mode)+'==="scroll"){',
 ' var els=document.querySelectorAll("[class*=overflow],[style*=overflow],[class*=scroll],main,article");var pane=null;',
 ' for(var i=0;i<els.length&&i<100;i++){var q=els[i];var cs=window.getComputedStyle?window.getComputedStyle(q):null;var oy=cs?(cs.overflowY||cs.overflow||""):"";if(/auto|scroll/i.test(oy)&&q.clientHeight>200&&q.scrollHeight>q.clientHeight+300&&(!pane||q.scrollHeight>pane.scrollHeight))pane=q;}',
 ' if(pane){pane.scrollTop=Math.min(pane.scrollHeight,pane.scrollTop+Math.max(500,pane.clientHeight*1.1));',
 '  try{pane.dispatchEvent(new Event("scroll",{bubbles:true}));}catch(e){}',
 '  store.bottom=(pane.scrollTop+pane.clientHeight>=pane.scrollHeight-150)?1:0;',
 ' }else{',
 '  var total=Math.max(document.documentElement.scrollHeight,document.body.scrollHeight);',
 '  window.scrollBy(0,Math.max(550,window.innerHeight*1.1));',
 '  store.bottom=(window.scrollY+window.innerHeight>=total-180)?1:0;',
 ' }',
 ' var bs=document.querySelectorAll("button,[role=button]");',
 ' for(var k=0;k<bs.length&&k<120;k++){if(/(?:tải thêm ảnh|tải thêm trang|load more pages|load more images|xem thêm trang)/i.test(bs[k].textContent||""))bs[k].click();}',
 ' store.steps++;',
 '}',
 'collect();',
 'var state=document.getElementById("vbook-reader-state");',
 'if(!state){state=document.createElement("span");state.id="vbook-reader-state";state.style.display="none";document.body.appendChild(state);}',
 'state.setAttribute("data-vbook-bottom",String(store.bottom));',
 'state.setAttribute("data-vbook-step",String(store.steps));',
 '})();'
 ];
 return script.join('');
}
function gtPageUrl(s,base) {
 var u=gtAbs(s,base);
 if(!/^https?:\/\//i.test(u))return '';
 if(!/\.(?:jpe?g|png|webp|avif|gif)(?:[?#]|$)|\/_next\/image\?|[?&](?:url|image|src)=/i.test(u))return '';
 if(/\.(?:svg|ico)(?:[?#]|$)/i.test(u))return '';
 return u;
}
function gtPageList(doc,base) {
 var pages=[],seen={};if(!doc)return pages;
 var elems=doc.select('[data-vbook-page],.reading-content img,#readerarea img,[class*=reader] img,[class*=chapter-content] img,[class*=viewer] img');
 for(var i=0;i<elems.size();i++){
  var e=elems.get(i),u=gtPageUrl(e.attr('data-vbook-page')||e.attr('data-src')||e.attr('data-original')||e.attr('src')||e.attr('srcset').split(',')[0].trim().split(/\s+/)[0],base);
  if(u&&!seen[u.replace(/[?#].*$/,'')]){seen[u.replace(/[?#].*$/,'')]=1;pages.push(u);}
 }
 return pages;
}
function gtAppend(dst,src) {
 var seen={};for(var i=0;i<dst.length;i++)seen[dst[i].replace(/[?#].*$/,'')]=true;
 for(var j=0;j<src.length;j++){var k=src[j].replace(/[?#].*$/,'');if(!seen[k]){seen[k]=true;dst.push(src[j]);}}
}
// Network fallback: find a coherent group of page images loaded by the reader.
// Images must share their directory, appear at least twice, and must not be ads.
function gtResourcePages(browser,seed,base) {
 var urls=browser.urls(),groups={},best=[],seen={};if(!urls)return [];
 var len=typeof urls.length==='number'?urls.length:(typeof urls.size==='function'?urls.size():0);
 var seedPrefix='';if(seed.length){var a=seed[0].replace(/[?#].*$/,'');seedPrefix=a.substring(0,a.lastIndexOf('/')+1);}
 for(var i=0;i<len&&i<5000;i++){
  var raw=typeof urls.length==='number'?urls[i]:urls.get(i),u=gtPageUrl(raw,base);
  if(!u||/(?:avatar|logo|icon|banner|thumb|cover|captcha|advert|tracking)/i.test(u))continue;
  var bare=u.replace(/[?#].*$/,''),prefix=bare.substring(0,bare.lastIndexOf('/')+1);
  if(prefix.length<20||!prefix)continue;
  if(seedPrefix&&prefix!==seedPrefix)continue;
  if(!groups[prefix])groups[prefix]=[];
  if(!seen[bare]){seen[bare]=1;groups[prefix].push(u);}
 }
 var keys=Object.keys(groups);
 for(var k=0;k<keys.length;k++)if(groups[keys[k]].length>best.length)best=groups[keys[k]];
 // Without DOM confirmation, require a sequence to avoid returning unrelated images.
 if(!seed.length&&best.length<2)return [];
 best.sort(function(a,b){
  var x=a.match(/\/(\d+)(?:\.(?:jpe?g|png|webp|avif|gif))(?:[?#]|$)/i);
  var y=b.match(/\/(\d+)(?:\.(?:jpe?g|png|webp|avif|gif))(?:[?#]|$)/i);
  return x&&y?Number(x[1])-Number(y[1]):0;
 });
 return best;
}
function execute(url) {
 var target=gtChapUrl(url,GT_BASE+'/');
 if(!target)return Response.error('URL chương không hợp lệ');
 var pages=[],browser=null,errors=[],reachedEnd=false;
 try {
  browser=Engine.newBrowser();
  browser.launch(target,24000);
  browser.callJs(gtReaderAction('init'),2200);
  var last=0,idle=0,bottomIdle=0;
  for(var step=0;step<85;step++){
   var doc=browser.html();gtAppend(pages,gtPageList(doc,target));
   // In rare cases the site removes previously seen DOM images; the site's
   // in-page collector persists all previously observed pages in order.
   var state=gtFirst(doc,'#vbook-reader-state');
   var bottom=state&&state.attr('data-vbook-bottom')==='1';
   if(pages.length>last){idle=0;bottomIdle=0;}else{idle++;if(bottom)bottomIdle++;}
   last=pages.length;
   if(step%8===0)gtLog('chap '+target+' step='+step+' found='+pages.length+' bottom='+bottom);
   if(bottom&&bottomIdle>=8&&step>=16&&pages.length>0){reachedEnd=true;break;}
   try{browser.callJs(gtReaderAction('scroll'),950);}catch(e){errors.push(String(e));break;}
  }
  // Network may contain additional pages loaded by fetch before they enter the DOM.
  var network=gtResourcePages(browser,pages,target);
  gtLog('chap v2: final DOM='+pages.length+' network='+network.length+' end='+reachedEnd+' errors='+errors.join(' | '));
  // Only append network requests when they match the captured page directory.
  // Some sites load in arbitrary order; avoid merging without explicit evidence of order.
  if(!pages.length&&network.length)pages=network;
 } catch(e){errors.push(String(e));}
 finally{if(browser)try{browser.close();}catch(e){}}
 if(!pages.length)return Response.error('Không lấy được ảnh chương [v2: 0 ảnh]. HTML có thể chưa chứa ảnh hoặc website yêu cầu xác thực/đổi server. '+errors.join('; '));
 // Never silently mark a partially read chapter as complete.
 if(!reachedEnd)return Response.error('Chưa xác minh tải đủ ảnh ('+pages.length+' trang). Hãy thử lại hoặc kiểm tra log: '+errors.join('; '));
 return Response.success(pages);
}
