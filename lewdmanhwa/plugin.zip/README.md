# LewdManhwa vBook extension (experimental)

**Source:** https://lewdmanhwa.com (adult/18+)  
**Type:** `comic`, `tag: nsfw`  
**Status:** Offline-tested prototype, **NOT confirmed working inside vBook**.

## What was confirmed from live pages (2026-10-17)
- Catalogue: `/webtoons`, with pagination `?page=2` and sort query `?sort=latest` / `?sort=popular`.
- Title: `/webtoon/<slug>`.
- Chapter: `/webtoon/<slug>/chapter/<number>`, including decimal chapter names.
- Chapter image URL pattern: `/uploads/chapters/<id>/<chapter-id>/<file>.webp`.
- Some detail pages show the newest 12 chapters only, requiring **Show all** to reveal the rest.

The live HTML attributes and CSS classes were **not directly inspectable** using the available read-only site tool, so DOM selectors below are best-effort. The existence/behavior of the search query parameter `?search=` **has not been verified**. No claims of working production support.

## Files
```
plugin.json
icon.png
src/common.js
src/home.js
src/homecontent.js
src/search.js
src/detail.js
src/toc.js
src/chap.js
```

- `home.js` lists three catalogue filters.
- `homecontent.js` extracts titles from generic `/webtoon/<slug>` anchors and paginates using verified catalogue URLs.
- `search.js` first tries `?search=...`; if no matches, falls back to filtering paginated catalogue pages. It may be slow for books far into the catalogue.
- `detail.js` reads title from `h1`, cover and description from DOM/meta, and author best-effort.
- `toc.js` extracts chapter anchors. When a "Show all" button hides chapters, it attempts `Engine.newBrowser()` + button click; if this fails it can only return visible chapters.
- `chap.js` extracts `<img>` links from `img[src*=...], img[data-src*=...], img[alt^='Page ']` and emits image HTML.
- `common.js` contains shared helpers.

## Install
1. Use **plugin.zip** (ZIP root contains `plugin.json`, `icon.png`, `src/*`, without any parent folder).
2. Import through the vBook extension installation workflow. If the installed version does not accept local ZIP directly, follow its developer mode/extension tester process.
3. First test **Browse All**, then a title `https://lewdmanhwa.com/webtoon/inappropriate-new-employee`, then chapters and images.
4. If book results are empty, inspect live DOM and adjust `lmBooks()` in `src/common.js`.
5. If chapters stop at 12, check whether vBook Engine browser rendered the hidden chapter list or whether a separate page/API is required.
6. If images are blank, inspect `src`, `data-src`, and source image host/Referer requirements.

## Development test (offline only)
```sh
node tools/mock-test.js
for f in src/*.js; do node --check "$f"; done
```

## Notes
- The site may change its HTML layout, dynamically load chapters, or block automated requests.
- Only retrieve content where you have permission and respect rate limits and site terms. The extension does not attempt to bypass access controls.
- Test on your own device. Neither this prototype nor the fixtures can verify the live vBook JavaScript runtime.

Reference for vBook extension API: https://github.com/duongden/vbook
