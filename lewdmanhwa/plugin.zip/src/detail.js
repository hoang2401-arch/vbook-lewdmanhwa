load('common.js');
function execute(url) {
    try {
        var target = lmAbs(url, LM_BASE + '/');
        var doc = lmGet(target);
        var name = lmText(doc, 'h1');
        if (!name) return Response.error('No book title (h1) found');
        // Prefer the book-specific Open Graph image; generic main/img could be a recommendation.
        var cover = lmAbs(lmAttr(doc, 'meta[property="og:image"]', 'content'), target);
        if (!cover) {
            var coverEl = lmFirst(doc, 'img[src*="/uploads/covers/"], img[data-src*="/uploads/covers/"], main img[alt], article img[alt]');
            cover = lmImage(coverEl, target);
        }
        var author = lmText(doc, 'a[href*="/author/"], a[href*="/authors/"]');
        // Avoid nextElementSibling(): not exposed by some vBook wrappers.
        // CSS adjacent-sibling selectors work through the documented select() API.
        var description = lmText(doc,
            'h2:matchesOwn(Synopsis) + p, h3:matchesOwn(Synopsis) + p, ' +
            'h2:matchesOwn(Synopsis) + div, h3:matchesOwn(Synopsis) + div');
        if (!description) description = lmAttr(doc, 'meta[name="description"]', 'content');
        var bodyText = lmText(doc, 'body');
        if (!author) {
            var m = bodyText.match(/\bBy:\s*([^\n]+?)(?=\s+(?:Romance|Drama|Comedy|Fantasy|Adult|Webtoons|Ongoing|Completed)\b)/i);
            if (m) author = lmClean(m[1]);
        }
        var ongoing = !/\bCompleted\s+Manhwa\b/i.test(bodyText);
        return Response.success({
            name: name,
            cover: cover,
            author: author || 'Unknown',
            description: description,
            detail: '',
            ongoing: ongoing
        });
    } catch (e) { return Response.error('Detail: ' + e.message); }
}
