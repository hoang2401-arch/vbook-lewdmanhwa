load('common.js');
// v10: use BOTH newest and oldest views. The older chapters are not
// reliably present in the initial HTML, even after scrolling newest-first.
// Do not collect reader navigation links ("First Ch.", "Continue Ch.").
function lmChapterName(raw, href) {
    var title = lmClean(raw);
    title = title.replace(/\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2}(?:,?\s+\d{4})?\s*$/i, '');
    title = title.replace(/\s+\d+(?:\.\d+)?\s*p(?:ages?)?\s*$/i, '');
    title = title.replace(/^(Ch(?:apter)?\.?\s*\d+(?:\.\d+)*)([A-Za-z])/, '$1 $2');
    return lmClean(title);
}
function lmChapters(doc, context) {
    if (!doc) return [];
    var anchors = doc.select('a[href*="/chapter/"]');
    var chapters = [], seen = {};
    for (var i = 0; i < anchors.size(); i++) {
        var a = anchors.get(i);
        var href = lmAbs(a.attr('href'), context).split('?')[0].replace(/\/$/, '');
        if (!/^https?:\/\/(?:www\.)?lewdmanhwa\.com\/webtoon\/[^\/?#]+\/chapter\/[^\/?#]+$/i.test(href)) continue;
        // IMPORTANT: navigation links on the same page point to chapter URLs.
        // They are NOT entries in the TOC. Only accept chapter-row labels.
        var raw = lmClean(a.text());
        if (!/^Ch(?:apter)?\.?\s*\d+(?:\.\d+)*/i.test(raw)) continue;
        var title = lmChapterName(raw, href);
        var chapterId = href.substring(href.lastIndexOf('/') + 1);
        if (!/^\d+(?:\.\d+)*$/.test(chapterId)) continue;
        if (seen[href]) continue;
        seen[href] = true;
        chapters.push({ name: title, url: href });
    }
    return chapters;
}
function lmTocLog(message) {
    try { if (typeof Console !== 'undefined') Console.log('LewdManhwa TOC v10: ' + message); }
    catch (err) {}
}
function lmExpectedChapters(doc) {
    if (!doc) return 0;
    var body = lmText(doc, 'body');
    var match = body.match(/Chapters\s*\(\s*(\d+)\s*\)/i);
    if (!match) match = body.match(/(\d+)\s+chapters\s+total/i);
    return match ? parseInt(match[1], 10) : 0;
}
function lmMergeChapters(result, found) {
    var seen = {};
    for (var i = 0; i < result.length; i++) seen[result[i].url] = 1;
    for (var j = 0; j < found.length; j++) {
        if (!seen[found[j].url]) {
            seen[found[j].url] = 1;
            result.push(found[j]);
        }
    }
}
function lmChapterNum(entry) {
    var m = entry.url.match(/\/chapter\/(\d+(?:\.\d+)*)$/i);
    return m ? m[1].split('.') : [];
}
function lmSortChapters(items) {
    items.sort(function(a, b) {
        var x = lmChapterNum(a), y = lmChapterNum(b), n = Math.max(x.length, y.length);
        for (var i = 0; i < n; i++) {
            var d = (parseInt(x[i] || '0', 10)) - (parseInt(y[i] || '0', 10));
            if (d) return d;
        }
        return 0;
    });
}
function lmBrowserAction(kind) {
    return '(function(){' +
        'var kind=' + JSON.stringify(kind) + ';' +
        'function txt(e){return (e.textContent||"").replace(/\\s+/g," ").trim().toLowerCase();}' +
        'var btns=document.querySelectorAll("button,[role=button]");' +
        'if(kind==="switch-oldest"){' +
        ' var sort=null;' +
        ' for(var i=0;i<btns.length;i++){' +
        '  if(txt(btns[i])==="newest first"){sort=btns[i];break;}' +
        ' }' +
        ' if(sort)sort.click();' +
        // Some UIs use a dropdown instead of a toggling button.
        ' var opt=document.querySelectorAll("[role=menuitem],[role=option]");' +
        ' for(var k=0;k<opt.length;k++){' +
        '  if(txt(opt[k])==="oldest first"){opt[k].click();break;}' +
        ' }' +
        ' window.scrollTo(0,0);return;' +
        '}' +
        'for(var j=0;j<btns.length;j++){' +
        ' var text=txt(btns[j]);' +
        ' if(text.indexOf("show all")>=0||text.indexOf("load more")>=0){' +
        '  try{btns[j].click();}catch(e){}' +
        ' }' +
        '}' +
        'var links=document.querySelectorAll("a[href*=\\"/chapter/\\"]");' +
        'var last=null;' +
        'for(var z=0;z<links.length;z++){' +
        ' if(/^ch(?:apter)?\\.?\\s*\\d/i.test(txt(links[z])))last=links[z];' +
        '}' +
        'if(last){' +
        ' try{last.scrollIntoView({block:"end"});}catch(e){}' +
        ' var p=last,n=0;' +
        ' while(p&&n++<12){' +
        '  if(p.clientHeight>80 && p.scrollHeight>p.clientHeight+20){' +
        '   p.scrollTop=p.scrollHeight;' +
        '   try{p.dispatchEvent(new Event("scroll",{bubbles:true}));}catch(e){}' +
        '  }p=p.parentElement;' +
        ' }' +
        '}' +
        'var panes=document.querySelectorAll("[class*=overflow-y],[data-radix-scroll-area-viewport],[data-virtuoso-scroller],[role=list]");' +
        'for(var q=0;q<panes.length&&q<80;q++){' +
        ' var c=panes[q];' +
        ' if(c.clientHeight>80&&c.scrollHeight>c.clientHeight+20){' +
        '  c.scrollTop=c.scrollHeight;' +
        '  try{c.dispatchEvent(new Event("scroll",{bubbles:true}));}catch(e){}' +
        ' }' +
        '}' +
        'window.scrollTo(0,document.documentElement.scrollHeight);' +
    '})();';
}
function lmExpandChapters(url, chapters, expected) {
    if (typeof Engine === 'undefined' || !Engine.newBrowser) {
        lmTocLog('browser unavailable'); return chapters;
    }
    var browser = null;
    try {
        browser = Engine.newBrowser();
        browser.launch(url, 25000);
        var initial = browser.html();
        if (!expected) expected = lmExpectedChapters(initial);
        lmMergeChapters(chapters, lmChapters(initial, url));
        lmTocLog('initial=' + chapters.length + '/' + expected);
        // First collect newest items. Previous v9 collected only the upper end.
        // Therefore spend more requests on the *oldest* view.
        for (var phase = 0; phase < 2; phase++) {
            if (phase === 1) {
                try { browser.callJs(lmBrowserAction('switch-oldest'), 1800); }
                catch (e) { lmTocLog('switch oldest failed: ' + String(e)); }
                lmMergeChapters(chapters, lmChapters(browser.html(), url));
                lmTocLog('oldest-first after switch=' + chapters.length);
            }
            var limit = phase === 0 ? 10 : 24;
            var idle = 0, prev = chapters.length;
            for (var step = 0; step < limit; step++) {
                if (expected && chapters.length >= expected) break;
                try { browser.callJs(lmBrowserAction('scroll'), 1200); }
                catch (e) { lmTocLog('scroll failed: ' + String(e)); break; }
                lmMergeChapters(chapters, lmChapters(browser.html(), url));
                lmTocLog((phase === 0 ? 'newest' : 'oldest') + ' ' + (step+1) + '=' + chapters.length + '/' + expected);
                idle = chapters.length === prev ? idle+1 : 0;
                prev = chapters.length;
                if (idle >= 6 && step >= 8) break;
            }
            if (expected && chapters.length >= expected) break;
        }
    } catch (e) { lmTocLog('browser error=' + String(e.message || e)); }
    finally { if (browser) { try { browser.close(); } catch (e) {} } }
    return chapters;
}
function execute(url) {
    var target = lmAbs(url, LM_BASE + '/');
    var chapters = [], expected = 0, errors = [];
    try {
        var doc = lmGet(target);
        expected = lmExpectedChapters(doc);
        lmMergeChapters(chapters, lmChapters(doc, target));
        lmTocLog('HTTP=' + chapters.length + '/' + expected);
    } catch (e) { errors.push(String(e.message || e)); }
    if (!expected || chapters.length < expected) lmExpandChapters(target, chapters, expected);
    if (!chapters.length) return Response.error('Cannot load chapter list: ' + errors.join('; '));
    lmSortChapters(chapters);
    lmTocLog('FINAL=' + chapters.length + '/' + (expected || '?') + ', first=' + chapters[0].name + ', last=' + chapters[chapters.length-1].name);
    return Response.success(chapters);
}
