load('common.js');
// The site places chapter names, page counts and dates inside the same <a>.
// Example: 'Ch. 11.01Notice. 1p Jun 3' should display 'Ch. 11.01 Notice.'
function lmChapterName(raw, href) {
    var title = lmClean(raw);
    // Remove a publication date at the end, but keep side-story titles intact.
    title = title.replace(/\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2}(?:,?\s+\d{4})?\s*$/i, '');
    // Remove page count (e.g. 146p, 1p, 14 pages) separately.
    title = title.replace(/\s+\d+(?:\.\d+)?\s*p(?:ages?)?\s*$/i, '');
    // The source sometimes concatenates a chapter number and subtitle.
    // Ch. 41.04Side.4 => Ch. 41.04 Side.4
    title = title.replace(/^(Ch(?:apter)?\.?\s*\d+(?:\.\d+)*)([A-Za-z])/, '$1 $2');
    title = lmClean(title);
    if (!title) {
        var id = href.replace(/\/$/, '').split('/').pop();
        title = 'Ch. ' + id;
    }
    return title;
}
function lmChapters(doc, context) {
    var anchors = doc.select('a[href*="/chapter/"]');
    var items = [], seen = {};
    for (var i = 0; i < anchors.size(); i++) {
        var a = anchors.get(i);
        var href = lmAbs(a.attr('href'), context).split('?')[0];
        if (!/^https?:\/\/lewdmanhwa\.com\/webtoon\/[^\/?#]+\/chapter\/[^\/?#]+\/?$/i.test(href)) continue;
        if (seen[href]) continue;
        var title = lmChapterName(a.text(), href);
        if (/^Read First Chapter$/i.test(title) || /^Latest Ch\./i.test(title)) continue;
        if (!title) title = 'Chapter ' + href.split('/').pop();
        seen[href] = true;
        items.push({ name: title, url: href });
    }
    return items;
}
function lmTocLog(value) {
    try { if (typeof Console !== 'undefined') Console.log('LewdManhwa TOC: ' + value); } catch (ignored) {}
}
function lmExpectedChapters(doc) {
    var body = lmText(doc, 'body');
    var match = body.match(/Chapters\s*\(\s*(\d+)\s*\)/i);
    return match ? parseInt(match[1], 10) : 0;
}
function lmTryExpandedChapters(target, initial, total) {
    if (typeof Engine === 'undefined' || !Engine.newBrowser) return initial;
    var browser = null;
    var best = initial;
    try {
        browser = Engine.newBrowser();
        browser.launch(target, 25000);
        var first = browser.html();
        var found = lmChapters(first, target);
        if (found.length > best.length) best = found;
        lmTocLog('browser initial=' + found.length + ', expected=' + total);
        if (total && best.length >= total) return best;
        // LewdManhwa's Show all can load chapters asynchronously in batches.
        // Retry buttons/scroll after the app hydrates and the next batch appears.
        for (var i = 0; i < 7; i++) {
            var js = '(function(){' +
              'var btns=document.querySelectorAll("button,[role=button]");' +
              'for(var k=0;k<btns.length;k++){' +
              ' var t=(btns[k].textContent||"").toLowerCase();' +
              ' if(t.indexOf("show all")>=0||t.indexOf("load more")>=0||t.indexOf("show more chapters")>=0){' +
              'btns[k].scrollIntoView({block:"center"}); btns[k].click(); break;}' +
              '}' +
              'window.scrollTo(0,document.documentElement.scrollHeight);' +
              '})();';
            try { browser.callJs(js, 1800); }
            catch (e) { lmTocLog('browser click failed=' + String(e.message || e)); break; }
            var expanded = lmChapters(browser.html(), target);
            if (expanded.length > best.length) best = expanded;
            lmTocLog('expansion ' + (i + 1) + ': ' + best.length + '/' + total);
            if (total && best.length >= total) break;
        }
    } catch (e) { lmTocLog('browser error=' + String(e.message || e)); }
    finally { if (browser) { try { browser.close(); } catch (ignored) {} } }
    return best;
}
function execute(url) {
    var target = lmAbs(url, LM_BASE + '/');
    var chapters = [], expected = 0, errors = [];
    try {
        var doc = lmGet(target);
        chapters = lmChapters(doc, target);
        expected = lmExpectedChapters(doc);
    } catch (e) { errors.push(String(e.message || e)); }
    if (!expected || chapters.length < expected) {
        chapters = lmTryExpandedChapters(target, chapters, expected);
    }
    if (!chapters.length) return Response.error('No chapter links found: ' + errors.join('; '));
    if (expected > chapters.length) {
        // Do not fabricate URLs for missing chapters; report a partial list.
        lmTocLog('WARNING: only found ' + chapters.length + '/' + expected + ' chapters');
    }
    chapters.reverse();
    return Response.success(chapters);
}
