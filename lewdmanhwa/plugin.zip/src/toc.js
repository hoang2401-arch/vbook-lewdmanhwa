load('common.js');
// v9: The site initially renders ~12 newest chapters, then lazily loads older
// chapter batches after "Show all" and scrolling the chapter list.
// Gather URLs from *every* snapshot instead of choosing the longest snapshot.
function lmChapterName(raw, href) {
    var title = lmClean(raw);
    title = title.replace(/\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2}(?:,?\s+\d{4})?\s*$/i, '');
    title = title.replace(/\s+\d+(?:\.\d+)?\s*p(?:ages?)?\s*$/i, '');
    title = title.replace(/^(Ch(?:apter)?\.?\s*\d+(?:\.\d+)*)([A-Za-z])/, '$1 $2');
    title = lmClean(title);
    if (!title) title = 'Ch. ' + href.replace(/\/$/, '').split('/').pop();
    return title;
}
function lmChapters(doc, context) {
    var anchors = doc.select('a[href*="/chapter/"]');
    var chapters = [], seen = {};
    for (var i = 0; i < anchors.size(); i++) {
        var a = anchors.get(i);
        var href = lmAbs(a.attr('href'), context).split('?')[0];
        if (!/^https?:\/\/(?:www\.)?lewdmanhwa\.com\/webtoon\/[^\/?#]+\/chapter\/[^\/?#]+\/?$/i.test(href)) continue;
        if (seen[href]) continue;
        var title = lmChapterName(a.text(), href);
        // Links elsewhere on the page (e.g. "Read First Chapter") are not
        // entries in the TOC. Exclude them without guessing additional URLs.
        if (/^Read First Chapter$/i.test(title) || /^Latest Ch\./i.test(title)) continue;
        seen[href] = true;
        chapters.push({ name: title, url: href });
    }
    return chapters;
}
function lmTocLog(message) {
    try { if (typeof Console !== 'undefined') Console.log('LewdManhwa TOC v9: ' + message); }
    catch (e) {}
}
function lmExpectedChapters(doc) {
    if (!doc) return 0;
    var body = lmText(doc, 'body');
    var match = body.match(/Chapters\s*\(\s*(\d+)\s*\)/i);
    return match ? parseInt(match[1], 10) : 0;
}
function lmMergeChapters(result, found) {
    for (var i = 0; i < found.length; i++) {
        var entry = found[i];
        var seen = false;
        for (var j = 0; j < result.length; j++) {
            if (result[j].url === entry.url) { seen = true; break; }
        }
        if (!seen) result.push(entry);
    }
    return result;
}
function lmChapterSortKey(entry) {
    var match = entry.name.match(/(?:Ch(?:apter)?\.?)\s*(\d+(?:\.\d+)*)/i);
    if (!match) match = entry.url.match(/\/chapter\/(\d+(?:\.\d+)*)/i);
    if (!match) return -1;
    // Compare dotted numeric parts separately: Ch. 11.10 > Ch. 11.9.
    var bits = match[1].split('.');
    var out = [];
    for (var i = 0; i < bits.length; i++) out.push(parseInt(bits[i], 10) || 0);
    return out;
}
function lmSortChapters(items) {
    items.sort(function(a, b) {
        var x = lmChapterSortKey(a), y = lmChapterSortKey(b);
        if (x === -1 && y === -1) return 0;
        if (x === -1) return -1;
        if (y === -1) return 1;
        for (var i = 0; i < Math.max(x.length, y.length); i++) {
            var d = (x[i] || 0) - (y[i] || 0);
            if (d) return d;
        }
        return 0;
    });
    return items;
}
// This JavaScript executes INSIDE the website's browser DOM, not in the
// extension's jsoup wrapper (whose element.parent() method is unavailable).
function lmBrowserAction(step) {
    return '(function(){' +
      'var nodes=document.querySelectorAll("button,[role=button]");' +
      'for(var i=0;i<nodes.length;i++){' +
      ' var t=(nodes[i].textContent||"").trim().toLowerCase();' +
      ' if(t.indexOf("show all")>=0||t.indexOf("load more")>=0||t.indexOf("show more chapters")>=0){' +
      '  try{nodes[i].click();}catch(e){}' +
      ' }' +
      '}' +
      'var links=document.querySelectorAll("a[href*=\\"/chapter/\\"]");' +
      'var last=links.length?links[links.length-1]:null;' +
      'if(last){' +
      ' try{last.scrollIntoView({block:"end"});}catch(e){}' +
      ' var e=last, n=0;' +
      ' while(e&&n++<12){' +
      '  if(e.scrollHeight>e.clientHeight+30&&e.clientHeight>0){' +
      '   e.scrollTop=e.scrollHeight;' +
      '   try{e.dispatchEvent(new Event("scroll",{bubbles:true}));}catch(err){}' +
      '  }' +
      '  e=e.parentElement;' +
      ' }' +
      '}' +
      'var candidates=document.querySelectorAll("[class*=overflow-y], [data-radix-scroll-area-viewport], [role=list], [data-virtuoso-scroller]");' +
      'for(var j=0;j<candidates.length&&j<60;j++){' +
      ' var c=candidates[j];' +
      ' if(c.scrollHeight>c.clientHeight+30&&c.clientHeight>0){' +
      '  c.scrollTop=c.scrollHeight;' +
      '  try{c.dispatchEvent(new Event("scroll",{bubbles:true}));}catch(err){}' +
      ' }' +
      '}' +
      'window.scrollTo(0,document.documentElement.scrollHeight);' +
      '})();';
}
function lmExpandChapters(url, chapters, expected) {
    if (typeof Engine === 'undefined' || !Engine.newBrowser) {
        lmTocLog('browser unavailable');
        return chapters;
    }
    var browser = null;
    try {
        browser = Engine.newBrowser();
        browser.launch(url, 25000);
        var initial = browser.html();
        if (!expected) expected = lmExpectedChapters(initial);
        lmMergeChapters(chapters, lmChapters(initial, url));
        lmTocLog('browser start=' + chapters.length + '/' + expected);
        if (expected && chapters.length >= expected) return chapters;
        var previous = chapters.length, idle = 0;
        // Browser waits between scroll steps so React / IntersectionObserver
        // can request and mount the next batch of chapters.
        for (var step = 0; step < 16; step++) {
            try { browser.callJs(lmBrowserAction(step), 1500); }
            catch (err) { lmTocLog('browser scroll error=' + String(err)); break; }
            lmMergeChapters(chapters, lmChapters(browser.html(), url));
            lmTocLog('scroll ' + (step + 1) + '=' + chapters.length + '/' + expected);
            if (expected && chapters.length >= expected) break;
            if (chapters.length === previous) idle++;
            else idle = 0;
            previous = chapters.length;
            // Allow extra idle rounds for network delays, bounded for speed.
            if (idle >= 5 && step >= 8) break;
        }
    } catch (e) { lmTocLog('browser error=' + String(e.message || e)); }
    finally { if (browser) { try { browser.close(); } catch (e) {} } }
    return chapters;
}
function execute(url) {
    var target = lmAbs(url, LM_BASE + '/');
    var chapters = [], expected = 0, errors = [];
    try {
        var doc = lmGet(target);
        expected = lmExpectedChapters(doc);
        lmMergeChapters(chapters, lmChapters(doc, target));
        lmTocLog('HTTP=' + chapters.length + '/' + expected);
    } catch (err) { errors.push(String(err.message || err)); }
    if (!expected || chapters.length < expected) {
        chapters = lmExpandChapters(target, chapters, expected);
    }
    if (!chapters.length) return Response.error('Cannot find chapters: ' + errors.join('; '));
    lmSortChapters(chapters);
    lmTocLog('FINAL=' + chapters.length + '/' + (expected || '?') + ', first=' + chapters[0].name + ', last=' + chapters[chapters.length - 1].name);
    return Response.success(chapters);
}
