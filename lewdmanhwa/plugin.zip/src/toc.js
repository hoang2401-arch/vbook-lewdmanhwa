load('common.js');
// The site places chapter names, page counts and dates inside the same <a>.
// Example: 'Ch. 11.01Notice. 1p Jun 3' should display 'Ch. 11.01 Notice.'
function lmChapterName(raw, href) {
    var title = lmClean(raw);
    // Remove a publication date at the end, but keep side-story titles intact.
    title = title.replace(/\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2}(?:,?\s+\d{4})?\s*$/i, '');
    // Remove page count (e.g. 146p, 1p, 14 pages) separately.
    title = title.replace(/\s+\d+(?:\.\d+)?\s*p(?:ages?)?\s*$/i, '');
    // The source sometimes concatenates a chapter number and subtitle.
    // Ch. 41.04Side.4 => Ch. 41.04 Side.4
    title = title.replace(/^(Ch(?:apter)?\.?\s*\d+(?:\.\d+)*)([A-Za-z])/, '$1 $2');
    title = lmClean(title);
    if (!title) {
        var id = href.replace(/\/$/, '').split('/').pop();
        title = 'Ch. ' + id;
    }
    return title;
}
function lmChapters(doc, context) {
    var anchors = doc.select('a[href*="/chapter/"]');
    var items = [], seen = {};
    for (var i = 0; i < anchors.size(); i++) {
        var a = anchors.get(i);
        var href = lmAbs(a.attr('href'), context).split('?')[0];
        if (!/^https?:\/\/lewdmanhwa\.com\/webtoon\/[^\/?#]+\/chapter\/[^\/?#]+\/?$/i.test(href)) continue;
        if (seen[href]) continue;
        var title = lmChapterName(a.text(), href);
        if (/^Read First Chapter$/i.test(title) || /^Latest Ch\./i.test(title)) continue;
        if (!title) title = 'Chapter ' + href.split('/').pop();
        seen[href] = true;
        items.push({ name: title, url: href });
    }
    return items;
}
function execute(url) {
    var target = lmAbs(url, LM_BASE + '/');
    try {
        var doc = lmGet(target);
        var chapters = lmChapters(doc, target);
        // LewdManhwa shows 12 chapters on some SSR pages and a "Show all" button.
        // Click that button in vBook's headless browser to render full list.
        var whole = lmText(doc, 'body').match(/Chapters\s*\((\d+)\)/i);
        var total = whole ? parseInt(whole[1], 10) : 0;
        if (total > chapters.length && typeof Engine !== 'undefined' && Engine.newBrowser) {
            var browser = null;
            try {
                browser = Engine.newBrowser();
                browser.launch(target, 20000);
                browser.callJs('(function(){var b=Array.prototype.slice.call(document.querySelectorAll("button"));for(var i=0;i<b.length;i++){if(/show all/i.test(b[i].textContent)){b[i].click();break;}}})()', 4000);
                var rendered = browser.html();
                var expanded = lmChapters(rendered, target);
                if (expanded.length > chapters.length) chapters = expanded;
            } catch (ignored) { /* Keep server-rendered chapters as fallback. */ }
            finally { if (browser) { try { browser.close(); } catch (ignoredClose) {} } }
        }
        if (!chapters.length) return Response.error('No chapter links found');
        // Site renders newest first. Use chronological order for the reader.
        chapters.reverse();
        return Response.success(chapters);
    } catch (e) { return Response.error('TOC: ' + e.message); }
}
