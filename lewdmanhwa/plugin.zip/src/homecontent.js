load('common.js');
function execute(url, page) {
    try {
        var number = Math.max(1, parseInt(page || '1', 10) || 1);
        var join = url.indexOf('?') >= 0 ? '&' : '?';
        var target = url + (number === 1 ? '' : join + 'page=' + number);
        var doc = lmGet(target);
        var books = lmBooks(doc, target);
        var next = lmNextPage(doc, number);
        return Response.success(books, next);
    } catch (e) { return Response.error('Browse: ' + e.message); }
}
