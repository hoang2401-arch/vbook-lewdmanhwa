function execute() {
    return Response.success([
        { title: "Smut", input: "https://lewdmanhwa.com/webtoons?genres=smut", script: "homecontent.js" },
        { title: "Drama", input: "https://lewdmanhwa.com/webtoons?genres=drama", script: "homecontent.js" },
        { title: "Romance", input: "https://lewdmanhwa.com/webtoons?genres=romance", script: "homecontent.js" },
        { title: "Mature", input: "https://lewdmanhwa.com/webtoons?genres=mature", script: "homecontent.js" },
        { title: "Yaoi", input: "https://lewdmanhwa.com/webtoons?genres=yaoi", script: "homecontent.js" },
        { title: "Josei", input: "https://lewdmanhwa.com/webtoons?genres=josei", script: "homecontent.js" },
        { title: "Fantasy", input: "https://lewdmanhwa.com/webtoons?genres=fantasy", script: "homecontent.js" },
        { title: "Comedy", input: "https://lewdmanhwa.com/webtoons?genres=comedy", script: "homecontent.js" },
        { title: "Psychological", input: "https://lewdmanhwa.com/webtoons?genres=psychological", script: "homecontent.js" },
        { title: "Historical", input: "https://lewdmanhwa.com/webtoons?genres=historical", script: "homecontent.js" },
        { title: "Harem", input: "https://lewdmanhwa.com/webtoons?genres=harem", script: "homecontent.js" },
        { title: "Slice of Life", input: "https://lewdmanhwa.com/webtoons?genres=slice-of-life", script: "homecontent.js" },
        { title: "Manhwa", input: "https://lewdmanhwa.com/webtoons?genres=manhwa", script: "homecontent.js" },
        { title: "Action", input: "https://lewdmanhwa.com/webtoons?genres=action", script: "homecontent.js" },
        { title: "Supernatural", input: "https://lewdmanhwa.com/webtoons?genres=supernatural", script: "homecontent.js" },
        { title: "Hentai", input: "https://lewdmanhwa.com/webtoons?genres=hentai", script: "homecontent.js" }
    ]);
}
