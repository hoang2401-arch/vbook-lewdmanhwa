load('common.js');
function execute(key, page) {
    try {
        var query = lmClean(key).toLowerCase();
        if (!query) return Response.success([], null);
        // First try the likely search query parameter. This endpoint is NOT verified.
        // If it fails/ignores search, scan catalogue pages one at a time.
        var step = String(page || 'try');
        var doc, next = null, target, number;
        if (step === 'try') {
            target = LM_BASE + '/webtoons?search=' + encodeURIComponent(key);
            try {
                doc = lmGet(target);
                var queried = lmBooks(doc, target);
                var filtered = [];
                for (var k = 0; k < queried.length; k++) {
                    if (queried[k].name.toLowerCase().indexOf(query) !== -1) filtered.push(queried[k]);
                }
                if (filtered.length) {
                    next = lmNextPage(doc, 1);
                    return Response.success(filtered, next ? 'direct:' + next : null);
                }
            } catch (ignored) { /* Fall back to the verified catalogue route. */ }
            step = 'scan:1';
        }
        var direct = step.indexOf('direct:') === 0;
        number = parseInt(step.split(':')[1], 10) || 1;
        if (number > 150) return Response.success([], null);
        if (direct) target = LM_BASE + '/webtoons?search=' + encodeURIComponent(key) + '&page=' + number;
        else target = LM_BASE + '/webtoons' + (number > 1 ? '?page=' + number : '');
        doc = lmGet(target);
        var all = lmBooks(doc, target), result = [];
        for (var i = 0; i < all.length; i++) {
            if (all[i].name.toLowerCase().indexOf(query) !== -1) result.push(all[i]);
        }
        next = lmNextPage(doc, number);
        return Response.success(result, next ? (direct ? 'direct:' : 'scan:') + next : null);
    } catch (e) { return Response.error('Search: ' + e.message); }
}
