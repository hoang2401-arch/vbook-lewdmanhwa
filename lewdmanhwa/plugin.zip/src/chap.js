load('common.js');
function lmPages(doc, context) {
    // Actual site chapter images use /uploads/chapters/.../*.webp.
    var els = doc.select('img[src*="/uploads/chapters/"], img[data-src*="/uploads/chapters/"], img[alt^="Page "]');
    var pages = [], seen = {};
    for (var i = 0; i < els.size(); i++) {
        var e = els.get(i), link = lmImage(e, context);
        if (!link || seen[link]) continue;
        // Reject site icons/covers, even when alt is "Page...".
        if (link.indexOf('/uploads/chapters/') === -1 && !/\.(jpe?g|png|webp)(\?|$)/i.test(link)) continue;
        seen[link] = true;
        pages.push('<img src="' + lmEsc(link) + '" alt="Page ' + (pages.length + 1) + '" />');
    }
    return pages;
}
function execute(url) {
    var target = lmAbs(url, LM_BASE + '/');
    try {
        var pages = lmPages(lmGet(target), target);
        if (!pages.length && typeof Engine !== 'undefined' && Engine.newBrowser) {
            var browser = null;
            try {
                browser = Engine.newBrowser();
                browser.launch(target, 20000);
                var rendered = browser.html();
                pages = lmPages(rendered, target);
            } catch (ignored) {} finally {
                if (browser) { try { browser.close(); } catch (ignoredClose) {} }
            }
        }
        if (!pages.length) return Response.error('No chapter page images found');
        return Response.success(pages.join('\n'));
    } catch (e) { return Response.error('Chapter: ' + e.message); }
}
