load('common.js');
// v8: For comic chapters, return URLs as an array, not HTML markup.
// Load browser only when HTTP extraction yields no pages.
function lmChapLog(s) {
    try { if (typeof Console !== 'undefined') Console.log('LewdManhwa chap v8: ' + s); }
    catch(ignore) {}
}
function lmPageUrl(raw, base) {
    var u = lmAbs(raw, base);
    if (!u || !/^https?:\/\//i.test(u)) return '';
    if (!/\/uploads\/chapters\/[^?#]+\.(?:webp|png|jpe?g|avif)(?:[?#]|$)/i.test(u)) return '';
    return u;
}
function lmCollect(pages, seen, raw, base) {
    var u = lmPageUrl(raw, base);
    if (u && !seen[u]) { seen[u] = true; pages.push(u); }
}
function lmFromDoc(doc, base) {
    var pages=[], seen={};
    if (!doc) return pages;
    var imgs=doc.select('img');
    for (var i=0; i<imgs.size(); i++) {
        var img=imgs.get(i);
        // Prefer real image URL; src can be a loading placeholder.
        var attrs=['data-src','data-original','data-lazy-src','data-full-src','src'];
        for (var j=0; j<attrs.length; j++) {
            lmCollect(pages, seen, img.attr(attrs[j]), base);
        }
        var srcset=String(img.attr('data-srcset') || img.attr('srcset') || '');
        if (srcset) lmCollect(pages, seen, srcset.split(',')[0].trim().split(/\s+/)[0], base);
    }
    return pages;
}
function lmFromHtml(text, base) {
    text=String(text || '').replace(/\\u002[fF]/g, '/').replace(/\\\//g, '/')
       .replace(/&amp;/g, '&').replace(/&#x2F;/gi, '/');
    var re=/(?:https?:\/\/[^\s"'<>\\]*)?\/uploads\/chapters\/[\w.%\/\-]+?\.(?:webp|png|jpe?g|avif)(?:\?[^\s"'<>&\\]*)?/gi;
    var seen={}, pages=[], m;
    while ((m=re.exec(text))!==null) lmCollect(pages,seen,m[0],base);
    return pages;
}
function lmBetter(a,b) { return b.length>a.length ? b : a; }
function lmBrowserPages(url) {
    var browser=null, pages=[];
    try {
        if (typeof Engine==='undefined' || !Engine.newBrowser) return [];
        browser=Engine.newBrowser();
        browser.launch(url, 15000);
        pages=lmFromDoc(browser.html(), url);
        // Some websites inject images after rendering. One bounded scroll retry.
        if (!pages.length) {
            try {
                browser.callJs('window.scrollTo(0, document.body.scrollHeight);', 1200);
                pages=lmFromDoc(browser.html(), url);
            } catch(e) { lmChapLog('scroll: '+String(e)); }
        }
    } catch(e) { lmChapLog('browser: '+String(e)); }
    finally { if (browser) { try { browser.close(); } catch(ignore) {} } }
    return pages;
}
function execute(url) {
    var target=lmAbs(url,LM_BASE+'/');
    var pages=[], errors=[];
    try {
        var res=fetch(target, {headers:{'Referer':LM_BASE+'/'}});
        if (!res.ok) errors.push('HTTP '+res.status);
        else {
            var body=res.text();
            pages=lmFromHtml(body,target);
            try { pages=lmBetter(pages,lmFromDoc(Html.parse(body),target)); }
            catch(e) { lmChapLog('parse: '+String(e)); }
            lmChapLog('HTTP images='+pages.length);
        }
    } catch(e) { errors.push('fetch: '+String(e)); }
    // IMPORTANT: do not start a browser after successfully extracting pages.
    if (!pages.length) pages=lmBrowserPages(target);
    lmChapLog('final images='+pages.length+' first='+(pages[0]||'none'));
    if (!pages.length) {
        return Response.error('No chapter images found. '+errors.join('; '));
    }
    return Response.success(pages);
}
