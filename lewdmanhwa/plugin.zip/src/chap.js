load('common.js');
// v11: a chapter page may contain only the FIRST FIVE images in server HTML.
// Collect further pages while scrolling a browser, preserving every observed URL.
// Never claim a chapter with an observed incomplete page count is finished.
function lmChapLog(s) {
    try { if (typeof Console !== 'undefined') Console.log('LewdManhwa chap v11: ' + s); }
    catch(e) {}
}
function lmPageUrl(raw, base) {
    var u=lmAbs(raw,base);
    if (!/^https?:\/\//i.test(u)) return '';
    return /\/uploads\/chapters\/[^?#]+\.(?:webp|png|jpe?g|avif)(?:[?#]|$)/i.test(u) ? u : '';
}
function lmPushPage(result, seen, value, base) {
    var u=lmPageUrl(value,base);
    if (!u) return;
    // Avoid duplicate URLs that only differ in query parameters.
    var key=u.replace(/[?#].*$/,'');
    if (!seen[key]) { seen[key]=true; result.push(u); }
}
function lmAddPages(result,seen,candidates,base) {
    if (!candidates) return;
    for (var i=0; i<candidates.length; i++) lmPushPage(result,seen,candidates[i],base);
}
function lmFromDoc(doc,base) {
    var result=[], seen={};
    if (!doc) return result;
    var els=doc.select('img');
    for (var i=0;i<els.size();i++) {
        var e=els.get(i);
        var attrs=['data-src','data-original','data-lazy-src','data-full-src','src'];
        for (var j=0;j<attrs.length;j++) {
            var before=result.length;
            lmPushPage(result,seen,e.attr(attrs[j]),base);
            if(result.length>before) break;
        }
        var set=String(e.attr('data-srcset')||e.attr('srcset')||'');
        if(set) lmPushPage(result,seen,set.split(',')[0].trim().split(/\s+/)[0],base);
    }
    return result;
}
function lmFromHtml(text,base) {
    text=String(text||'').replace(/\\u002[fF]/g,'/').replace(/\\\//g,'/')
        .replace(/&amp;/g,'&').replace(/&#x2F;/gi,'/');
    var re=/(?:https?:\/\/[^\s"'<>\\]*)?\/uploads\/chapters\/[\w.%\/\-]+?\.(?:webp|png|jpe?g|avif)(?:\?[^\s"'<>&\\]*)?/gi;
    var result=[],seen={},m;
    while((m=re.exec(text))!==null) lmPushPage(result,seen,m[0],base);
    return result;
}
function lmPageNumber(url) {
    var m=String(url).match(/\/(\d+)\.(?:webp|png|jpe?g|avif)(?:[?#]|$)/i);
    return m?parseInt(m[1],10):-1;
}
function lmSorted(pages) {
    pages.sort(function(a,b) {
        var x=lmPageNumber(a),y=lmPageNumber(b);
        return x>=0&&y>=0 ? x-y : 0;
    });
    return pages;
}
function lmMissingNumberedPage(pages) {
    if (pages.length<2) return false;
    var sorted=lmSorted(pages.slice());
    for (var i=1;i<sorted.length;i++) {
        var a=lmPageNumber(sorted[i-1]),b=lmPageNumber(sorted[i]);
        if(a>=0&&b>=0&&b>a+1) return true;
    }
    return false;
}
// Check the chapter's stated number of pages on the book page (when listed).
// The catalogue contains labels such as "Ch. 74 168p".
function lmExpectedPageCount(target) {
    var p=target.indexOf('/chapter/');
    if(p<0) return 0;
    var book=target.substring(0,p),expected=0;
    try {
        var resp=fetch(book,{headers:{'Referer':LM_BASE+'/'}});
        if(!resp.ok) return 0;
        var doc=resp.html();
        var links=doc.select('a[href*="/chapter/"]');
        for(var i=0;i<links.size();i++) {
            var a=links.get(i),href=lmAbs(a.attr('href'),book).split('?')[0].replace(/\/$/,'');
            if(href!==target) continue;
            var match=lmClean(a.text()).match(/\b(\d+)\s*p(?:ages?)?\b/i);
            if(match) {expected=parseInt(match[1],10);break;}
        }
    } catch(e) {lmChapLog('page-count unavailable: '+String(e));}
    return expected>0&&expected<1000 ? expected:0;
}
function lmScrollScript() {
    // Runs INSIDE the loaded website, not in the vBook extension runtime.
    // Trigger both page scrolling and independently scrollable reader panes.
    return '(function(){'+
        'var imgs=document.querySelectorAll("img[src*=\\"/uploads/chapters/\\"],img[data-src*=\\"/uploads/chapters/\\"]");'+
        'var last=imgs.length?imgs[imgs.length-1]:null;'+
        'if(last){try{last.scrollIntoView({block:"end"});}catch(e){}}'+
        'var nodes=document.querySelectorAll("[class*=overflow-y],[style*=overflow],[data-virtuoso-scroller]");'+
        'for(var i=0;i<nodes.length&&i<60;i++){'+
        ' var n=nodes[i];if(n.clientHeight>50&&n.scrollHeight>n.clientHeight+10){'+
        '  n.scrollTop=n.scrollHeight;'+
        '  try{n.dispatchEvent(new Event("scroll",{bubbles:true}));}catch(e){}'+
        ' }}'+
        'window.scrollTo(0,Math.max(document.body.scrollHeight,document.documentElement.scrollHeight));'+
        'var btns=document.querySelectorAll("button");'+
        'for(var k=0;k<btns.length;k++){'+
        ' var s=(btns[k].textContent||"").toLowerCase();'+
        ' if(s.indexOf("load more pages")>=0||s.indexOf("show more pages")>=0){'+
        '  try{btns[k].click();}catch(e){}'+
        ' }}'+
    '})();';
}
function lmBrowserPages(target,seed,expected) {
    var pages=[],seen={};lmAddPages(pages,seen,seed,target);
    var browser=null;
    if(typeof Engine==='undefined'||!Engine.newBrowser) {
        lmChapLog('browser not available');return pages;
    }
    try {
        browser=Engine.newBrowser();
        browser.launch(target,20000);
        var idle=0,previous=0;
        // 85 steps handles long chapters (~5 pages loaded per batch).
        for(var step=0;step<85;step++) {
            try {lmAddPages(pages,seen,lmFromDoc(browser.html(),target),target);}
            catch(e) {lmChapLog('html step '+step+': '+String(e));}
            try {
                var urls=browser.urls();
                if(urls) {
                    if(typeof urls.length==='number') lmAddPages(pages,seen,urls,target);
                    else if(typeof urls.size==='function') {
                        for(var n=0;n<urls.size();n++) lmPushPage(pages,seen,urls.get(n),target);
                    }
                }
            } catch(e) { /* browser.urls() is optional on some vBook versions */ }
            if(step%5===0||pages.length!==previous)
                lmChapLog('browser step='+step+' pages='+pages.length+'/'+(expected||'?'));
            if(expected && pages.length>=expected) break;
            if(pages.length===previous) idle++; else idle=0;
            previous=pages.length;
            if(idle>=9&&step>=12) break;
            try {browser.callJs(lmScrollScript(),750);}
            catch(e) {lmChapLog('scroll step '+step+': '+String(e));break;}
        }
    } catch(e) {lmChapLog('browser error: '+String(e));}
    finally {if(browser)try{browser.close();}catch(e){}}
    return lmSorted(pages);
}

// v12: On this source the static HTML can expose only the first five 001.webp..005.webp.
// After the browser fails to extend the list, probe the next numbered page using
// an HTTP Range request. Only infer a contiguous set after verifying the first
// missing page and sampling intermediate pages. Never return a silent 5-page partial.
function lmNumberedPattern(pages) {
    var groups={};var best=null;
    for (var i=0;i<pages.length;i++) {
        var m=String(pages[i]).match(/^(https?:\/\/[^?#]+\/)(\d+)(\.(?:webp|png|jpe?g|avif))(\?[^#]*)?$/i);
        if(!m)continue;
        var key=m[1]+'|'+m[3]+'|'+(m[4]||'');
        if(!groups[key]) groups[key]={prefix:m[1],suffix:m[3],query:m[4]||'',width:m[2].length,max:0,min:999999,seen:{},count:0};
        var g=groups[key],n=parseInt(m[2],10);
        if(!g.seen[n]) {g.seen[n]=true;g.count++;}
        if(n>g.max)g.max=n;if(n<g.min)g.min=n;
        if(!best||g.count>best.count)best=g;
    }
    // Require a reliable sequence starting with 001,002,003 etc. Never extrapolate
    // from an unrelated cover image or an irregular filename scheme.
    if(!best||best.count<2||best.min!==1||best.max!==best.count)return null;
    return best;
}
function lmNumberedUrl(p,n) {
    var s=String(n);
    while(s.length<p.width)s='0'+s;
    return p.prefix+s+p.suffix+p.query;
}
function lmProbeImage(url,target) {
    try {
        var r=fetch(url,{headers:{'Referer':target,'Range':'bytes=0-0','Accept':'image/avif,image/webp,image/*'}});
        var st=Number(r.status||0);
        if(r.ok||st>=200&&st<300)return 1;
        if(st===404||st===410)return 0;
        lmChapLog('probe HTTP '+st+' '+url);return -1;
    } catch(e) {lmChapLog('probe error: '+String(e));return -1;}
}
function lmProbeSequence(pattern,target) {
    var lower=pattern.max;
    if(lower>=300)return {ok:false,reason:'Quá giới hạn 300 trang'};
    var first=lmProbeImage(lmNumberedUrl(pattern,lower+1),target);
    if(first!==1) {
        if(first===0 && lower>5) {
            var all=[];for(var i=1;i<=lower;i++)all.push(lmNumberedUrl(pattern,i));
            return {ok:true,pages:all,count:lower};
        }
        return {ok:false,reason:first===0?'Không tìm thấy ảnh tiếp theo':'Không xác minh được ảnh tiếp theo',count:lower};
    }
    lower++;
    var stride=1,upper=-1,attempts=0;
    while(lower<300 && attempts++<14) {
        var n=Math.min(301,lower+stride);
        var r=lmProbeImage(lmNumberedUrl(pattern,n),target);
        if(r<0)return {ok:false,reason:'Máy chủ chặn/không phản hồi khi kiểm tra trang '+n};
        if(r===0){upper=n;break;}
        lower=n;stride*=2;
    }
    if(upper<0)return {ok:false,reason:'Không xác định được trang cuối (giới hạn 300)'};
    // Between one confirmed existing page and one confirmed missing page,
    // discover the highest existing page with logarithmic probes.
    var lo=lower+1,hi=upper-1;
    while(lo<=hi) {
        var mid=Math.floor((lo+hi)/2);
        var status=lmProbeImage(lmNumberedUrl(pattern,mid),target);
        if(status<0)return {ok:false,reason:'Kiểm tra trang '+mid+' thất bại'};
        if(status===1){lower=mid;lo=mid+1;}else hi=mid-1;
    }
    // Periodic samples make numbering assumptions less risky. A missing
    // sample is an error, not a license to return broken URLs.
    for(var check=pattern.max+1;check<=lower;check+=20) {
        if(check===pattern.max+1)continue; // already confirmed
        if(lmProbeImage(lmNumberedUrl(pattern,check),target)!==1)
            return {ok:false,reason:'Không xác minh được tính liên tục tại trang '+check};
    }
    var result=[];
    for(var k=1;k<=lower;k++)result.push(lmNumberedUrl(pattern,k));
    lmChapLog('PROBE confirmed 1..'+lower+'; first missing='+upper+'; checks performed');
    return {ok:true,pages:result,count:lower};
}
function execute(url) {
    var target=lmAbs(url,LM_BASE+'/').split('?')[0].replace(/\/$/,'');
    var pages=[],seen={},errors=[];
    try {
        var resp=fetch(target,{headers:{'Referer':LM_BASE+'/'}});
        if(resp.ok) {
            var body=resp.text();
            lmAddPages(pages,seen,lmFromHtml(body,target),target);
            try {lmAddPages(pages,seen,lmFromDoc(Html.parse(body),target),target);}
            catch(e) {lmChapLog('HTML parse: '+String(e));}
        } else errors.push('HTTP '+resp.status);
    } catch(e) {errors.push('fetch: '+String(e));}
    pages=lmSorted(pages);
    lmChapLog('v12 HTTP images='+pages.length);
    var expected=lmExpectedPageCount(target);
    // Try confirmed, consecutive source-image names first. This avoids relying
    // on long scroll loops if the source serves only five SSR images.
    var seq=lmNumberedPattern(pages),probe=null;
    if(seq && pages.length<=5) {
        probe=lmProbeSequence(seq,target);
        lmChapLog('v12 initial probe: '+(probe.ok?'pages='+probe.count:probe.reason));
        if(probe.ok)pages=probe.pages;
    }
    // Fallback to browser when direct probing is unavailable or inconclusive.
    if(!probe||!probe.ok) {
        pages=lmBrowserPages(target,pages,expected);
        pages=lmSorted(pages);
        seq=lmNumberedPattern(pages);
        if(seq) {
            probe=lmProbeSequence(seq,target);
            lmChapLog('v12 browser probe: '+(probe.ok?'pages='+probe.count:probe.reason));
            if(probe.ok)pages=probe.pages;
        }
    }
    pages=lmSorted(pages);
    lmChapLog('v12 FINAL='+pages.length+' expected='+(expected||'?')+' boundary='+(probe&&probe.ok));
    if(!pages.length) return Response.error('Không tìm được ảnh chương. '+errors.join('; '));
    if(expected && pages.length<expected)
        return Response.error('Mới xác nhận '+pages.length+'/'+expected+' trang; chưa đủ chương.');
    if(lmMissingNumberedPage(pages))
        return Response.error('Phát hiện thiếu ảnh giữa chương. Vui lòng thử lại.');
    // Protect against the observed premature 5/5 ending (including a stale
    // page count of 5). A bounded-image chapter requires an independently
    // verified boundary, not merely five SSR elements or a catalogue label.
    if(pages.length<=5 && (!probe||!probe.ok))
        return Response.error('Nguồn trả về '+pages.length+' ảnh nhưng chưa xác minh hết chương. '+(probe?probe.reason:''));
    // When there is no catalogue count or verified source endpoint, browser
    // snapshots alone cannot prove that a longer chapter is complete.
    if(!expected && (!probe||!probe.ok))
        return Response.error('Đã lấy '+pages.length+' ảnh nhưng chưa xác minh trang cuối. Hãy tải lại.');
    return Response.success(pages);
}
