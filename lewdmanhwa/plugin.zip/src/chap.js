load('common.js');
// v11: a chapter page may contain only the FIRST FIVE images in server HTML.
// Collect further pages while scrolling a browser, preserving every observed URL.
// Never claim a chapter with an observed incomplete page count is finished.
function lmChapLog(s) {
    try { if (typeof Console !== 'undefined') Console.log('LewdManhwa chap v11: ' + s); }
    catch(e) {}
}
function lmPageUrl(raw, base) {
    var u=lmAbs(raw,base);
    if (!/^https?:\/\//i.test(u)) return '';
    return /\/uploads\/chapters\/[^?#]+\.(?:webp|png|jpe?g|avif)(?:[?#]|$)/i.test(u) ? u : '';
}
function lmPushPage(result, seen, value, base) {
    var u=lmPageUrl(value,base);
    if (!u) return;
    // Avoid duplicate URLs that only differ in query parameters.
    var key=u.replace(/[?#].*$/,'');
    if (!seen[key]) { seen[key]=true; result.push(u); }
}
function lmAddPages(result,seen,candidates,base) {
    if (!candidates) return;
    for (var i=0; i<candidates.length; i++) lmPushPage(result,seen,candidates[i],base);
}
function lmFromDoc(doc,base) {
    var result=[], seen={};
    if (!doc) return result;
    var els=doc.select('img');
    for (var i=0;i<els.size();i++) {
        var e=els.get(i);
        var attrs=['data-src','data-original','data-lazy-src','data-full-src','src'];
        for (var j=0;j<attrs.length;j++) {
            var before=result.length;
            lmPushPage(result,seen,e.attr(attrs[j]),base);
            if(result.length>before) break;
        }
        var set=String(e.attr('data-srcset')||e.attr('srcset')||'');
        if(set) lmPushPage(result,seen,set.split(',')[0].trim().split(/\s+/)[0],base);
    }
    return result;
}
function lmFromHtml(text,base) {
    text=String(text||'').replace(/\\u002[fF]/g,'/').replace(/\\\//g,'/')
        .replace(/&amp;/g,'&').replace(/&#x2F;/gi,'/');
    var re=/(?:https?:\/\/[^\s"'<>\\]*)?\/uploads\/chapters\/[\w.%\/\-]+?\.(?:webp|png|jpe?g|avif)(?:\?[^\s"'<>&\\]*)?/gi;
    var result=[],seen={},m;
    while((m=re.exec(text))!==null) lmPushPage(result,seen,m[0],base);
    return result;
}
function lmPageNumber(url) {
    var m=String(url).match(/\/(\d+)\.(?:webp|png|jpe?g|avif)(?:[?#]|$)/i);
    return m?parseInt(m[1],10):-1;
}
function lmSorted(pages) {
    pages.sort(function(a,b) {
        var x=lmPageNumber(a),y=lmPageNumber(b);
        return x>=0&&y>=0 ? x-y : 0;
    });
    return pages;
}
function lmMissingNumberedPage(pages) {
    if (pages.length<2) return false;
    var sorted=lmSorted(pages.slice());
    for (var i=1;i<sorted.length;i++) {
        var a=lmPageNumber(sorted[i-1]),b=lmPageNumber(sorted[i]);
        if(a>=0&&b>=0&&b>a+1) return true;
    }
    return false;
}
// Check the chapter's stated number of pages on the book page (when listed).
// The catalogue contains labels such as "Ch. 74 168p".
function lmExpectedPageCount(target) {
    var p=target.indexOf('/chapter/');
    if(p<0) return 0;
    var book=target.substring(0,p),expected=0;
    try {
        var resp=fetch(book,{headers:{'Referer':LM_BASE+'/'}});
        if(!resp.ok) return 0;
        var doc=resp.html();
        var links=doc.select('a[href*="/chapter/"]');
        for(var i=0;i<links.size();i++) {
            var a=links.get(i),href=lmAbs(a.attr('href'),book).split('?')[0].replace(/\/$/,'');
            if(href!==target) continue;
            var match=lmClean(a.text()).match(/\b(\d+)\s*p(?:ages?)?\b/i);
            if(match) {expected=parseInt(match[1],10);break;}
        }
    } catch(e) {lmChapLog('page-count unavailable: '+String(e));}
    return expected>0&&expected<1000 ? expected:0;
}
function lmScrollScript() {
    // Runs INSIDE the loaded website, not in the vBook extension runtime.
    // Trigger both page scrolling and independently scrollable reader panes.
    return '(function(){'+
        'var imgs=document.querySelectorAll("img[src*=\\"/uploads/chapters/\\"],img[data-src*=\\"/uploads/chapters/\\"]");'+
        'var last=imgs.length?imgs[imgs.length-1]:null;'+
        'if(last){try{last.scrollIntoView({block:"end"});}catch(e){}}'+
        'var nodes=document.querySelectorAll("[class*=overflow-y],[style*=overflow],[data-virtuoso-scroller]");'+
        'for(var i=0;i<nodes.length&&i<60;i++){'+
        ' var n=nodes[i];if(n.clientHeight>50&&n.scrollHeight>n.clientHeight+10){'+
        '  n.scrollTop=n.scrollHeight;'+
        '  try{n.dispatchEvent(new Event("scroll",{bubbles:true}));}catch(e){}'+
        ' }}'+
        'window.scrollTo(0,Math.max(document.body.scrollHeight,document.documentElement.scrollHeight));'+
        'var btns=document.querySelectorAll("button");'+
        'for(var k=0;k<btns.length;k++){'+
        ' var s=(btns[k].textContent||"").toLowerCase();'+
        ' if(s.indexOf("load more pages")>=0||s.indexOf("show more pages")>=0){'+
        '  try{btns[k].click();}catch(e){}'+
        ' }}'+
    '})();';
}
function lmBrowserPages(target,seed,expected) {
    var pages=[],seen={};lmAddPages(pages,seen,seed,target);
    var browser=null;
    if(typeof Engine==='undefined'||!Engine.newBrowser) {
        lmChapLog('browser not available');return pages;
    }
    try {
        browser=Engine.newBrowser();
        browser.launch(target,20000);
        var idle=0,previous=0;
        // 85 steps handles long chapters (~5 pages loaded per batch).
        for(var step=0;step<85;step++) {
            try {lmAddPages(pages,seen,lmFromDoc(browser.html(),target),target);}
            catch(e) {lmChapLog('html step '+step+': '+String(e));}
            try {
                var urls=browser.urls();
                if(urls) {
                    if(typeof urls.length==='number') lmAddPages(pages,seen,urls,target);
                    else if(typeof urls.size==='function') {
                        for(var n=0;n<urls.size();n++) lmPushPage(pages,seen,urls.get(n),target);
                    }
                }
            } catch(e) { /* browser.urls() is optional on some vBook versions */ }
            if(step%5===0||pages.length!==previous)
                lmChapLog('browser step='+step+' pages='+pages.length+'/'+(expected||'?'));
            if(expected && pages.length>=expected) break;
            if(pages.length===previous) idle++; else idle=0;
            previous=pages.length;
            if(idle>=9&&step>=12) break;
            try {browser.callJs(lmScrollScript(),750);}
            catch(e) {lmChapLog('scroll step '+step+': '+String(e));break;}
        }
    } catch(e) {lmChapLog('browser error: '+String(e));}
    finally {if(browser)try{browser.close();}catch(e){}}
    return lmSorted(pages);
}
function execute(url) {
    var target=lmAbs(url,LM_BASE+'/').split('?')[0].replace(/\/$/,'');
    var pages=[],seen={},errors=[];
    try {
        var resp=fetch(target,{headers:{'Referer':LM_BASE+'/'}});
        if(resp.ok) {
            var body=resp.text();
            lmAddPages(pages,seen,lmFromHtml(body,target),target);
            try {lmAddPages(pages,seen,lmFromDoc(Html.parse(body),target),target);}
            catch(e) {lmChapLog('HTML parse: '+String(e));}
        } else errors.push('HTTP '+resp.status);
    } catch(e) {errors.push('fetch: '+String(e));}
    lmChapLog('HTTP images='+pages.length);
    var expected=0;
    // Five initial images are the site's common SSR batch size; verify if complete.
    if(pages.length<=5) expected=lmExpectedPageCount(target);
    if(pages.length<=5 || (expected && pages.length<expected)) {
        pages=lmBrowserPages(target,pages,expected);
    }
    pages=lmSorted(pages);
    lmChapLog('FINAL='+pages.length+'/'+(expected||'?'));
    if(!pages.length) return Response.error('No chapter images found. '+errors.join('; '));
    if(expected && pages.length<expected)
        return Response.error('Chương mới tải được '+pages.length+'/'+expected+' trang. Vui lòng thử tải lại.');
    if(lmMissingNumberedPage(pages))
        return Response.error('Thiếu ảnh giữa chương (tải không liên tục). Vui lòng thử lại.');
    // On this site, five is the initial HTML limit, not proof of a full chapter.
    // Fail closed when the browser cannot extend five and no page count is available.
    if(pages.length===5 && !expected)
        return Response.error('Chỉ tìm được 5 trang đầu, chưa xác minh được phần còn lại. Vui lòng thử lại.');
    return Response.success(pages);
}
