load('common.js');

// v7: Handle blocked HTTP, browser-rendered images, lazy-loading and SSR images.
// Never rely on a single selector or assume fetch() is allowed by the website.
function lmChapLog(value) {
    try { if (typeof Console !== 'undefined') Console.log('LewdManhwa chap: ' + value); } catch (ignored) {}
}
function lmPushPage(pages, seen, raw, context) {
    var url = lmAbs(raw, context);
    if (!url || seen[url]) return;
    // Only images from the chapter directory, NOT unrelated logos / covers / ads.
    if (!/\/uploads\/chapters\/[^?#]+\.(?:webp|png|jpe?g|avif)(?:[?#]|$)/i.test(url)) return;
    seen[url] = true;
    pages.push(url);
}
function lmChapterPages(doc, context) {
    var pages = [], seen = {};
    if (!doc) return pages;
    var images = doc.select('img');
    for (var i = 0; i < images.size(); i++) {
        var item = images.get(i);
        var imageUrl = lmImage(item, context);
        lmPushPage(pages, seen, imageUrl, context);
        // Picture/source and lazy-loading plugins can have multiple attributes.
        var attributes = ['src', 'data-src', 'data-original', 'data-lazy-src', 'data-full-src'];
        for (var j = 0; j < attributes.length; j++) {
            var candidate = lmClean(item.attr(attributes[j]));
            if (candidate) lmPushPage(pages, seen, candidate, context);
        }
    }
    return pages;
}
function lmChapterPagesFromText(html, context) {
    // Server-rendered HTML and serialized React data may have URL-escaped slashes.
    var text = String(html || '').replace(/\\u002[fF]/g, '/')
        .replace(/\\\//g, '/').replace(/&amp;/g, '&').replace(/&#x2F;/gi, '/');
    var pattern = /(?:https?:\/\/[^\s"'<>\\]*)?\/uploads\/chapters\/[\w.%/\-]+?\.(?:webp|png|jpe?g|avif)(?:\?[^\s"'<>&\\]*)?/gi;
    var pages = [], seen = {}, match;
    while ((match = pattern.exec(text)) !== null) {
        lmPushPage(pages, seen, match[0], context);
    }
    return pages;
}
function lmBestPages(a, b) {
    // Preserve the order from the longer list, typically the browser-rendered page.
    return b.length > a.length ? b : a;
}
function lmTryBrowser(target) {
    var browser = null, best = [], error = '';
    try {
        if (typeof Engine === 'undefined' || !Engine.newBrowser) return { pages: [], error: 'browser engine unavailable' };
        browser = Engine.newBrowser();
        browser.launch(target, 25000);
        best = lmChapterPages(browser.html(), target);
        lmChapLog('browser initial images=' + best.length);
        // On this site, chapter images can be lazy-rendered after scrolling.
        // Avoid infinite loops or any attempt to guess unobserved image URLs.
        var scroll = '(function(){window.scrollTo(0, Math.max(0, document.documentElement.scrollHeight * 0.5));})();';
        for (var i = 0; i < 3; i++) {
            try {
                var position = i === 0 ? 0.5 : (i === 1 ? 0.9 : 1);
                scroll = '(function(){window.scrollTo(0, Math.max(0, document.documentElement.scrollHeight * ' + position + '));})();';
                browser.callJs(scroll, 1500);
                best = lmBestPages(best, lmChapterPages(browser.html(), target));
            } catch (scrollError) { error = 'scroll ' + String(scrollError); break; }
        }
        lmChapLog('browser final images=' + best.length);
    } catch (e) { error = String(e.message || e); lmChapLog('browser error=' + error); }
    finally { if (browser) { try { browser.close(); } catch (ignored) {} } }
    return { pages: best, error: error };
}
function execute(url) {
    var target = lmAbs(url, LM_BASE + '/');
    var pages = [], errors = [];
    // Independent try blocks are important: in v6 an HTTP exception prevented
    // the browser fallback from ever running.
    try {
        var response = fetch(target, { headers: { 'Referer': LM_BASE + '/', 'Accept': 'text/html' } });
        if (!response.ok) {
            errors.push('HTTP ' + response.status);
        } else {
            var html = response.text();
            pages = lmChapterPagesFromText(html, target);
            try { pages = lmBestPages(pages, lmChapterPages(Html.parse(html), target)); }
            catch (parseError) { lmChapLog('parse=' + String(parseError)); }
            lmChapLog('HTTP images=' + pages.length);
        }
    } catch (e) { errors.push('HTTP fetch: ' + String(e.message || e)); }

    // Try actual browser when HTTP returns no images, or when the page may be
    // lazy-loaded with more images than the server initially renders.
    var viaBrowser = lmTryBrowser(target);
    pages = lmBestPages(pages, viaBrowser.pages);
    if (viaBrowser.error) errors.push(viaBrowser.error);
    if (!pages.length) {
        return Response.error('No chapter images found (' + errors.join('; ') + '). Check vBook Logcat for details.');
    }
    var content = [];
    for (var i = 0; i < pages.length; i++) {
        content.push('<img src="' + lmEsc(pages[i]) + '" alt="Page ' + (i + 1) + '"/>');
    }
    lmChapLog('returning ' + pages.length + ' images');
    return Response.success(content.join('\n'));
}
