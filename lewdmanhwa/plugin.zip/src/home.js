function execute() {
    return Response.success([
        { title: 'Browse all', input: 'https://lewdmanhwa.com/webtoons', script: 'homecontent.js' },
        { title: 'Latest', input: 'https://lewdmanhwa.com/webtoons?sort=latest', script: 'homecontent.js' },
        { title: 'Popular', input: 'https://lewdmanhwa.com/webtoons?sort=popular', script: 'homecontent.js' }
    ]);
}
