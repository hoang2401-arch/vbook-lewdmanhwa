function execute() {
    return Response.success([
        { title: "Browse all", input: "https://lewdmanhwa.com/webtoons", script: "homecontent.js" },
        { title: "Latest", input: "https://lewdmanhwa.com/webtoons?sort=latest", script: "homecontent.js" },
        { title: "Popular", input: "https://lewdmanhwa.com/webtoons?sort=popular", script: "homecontent.js" },
        { title: "Smut", input: "https://lewdmanhwa.com/webtoons?genres=smut", script: "homecontent.js" },
        { title: "Drama", input: "https://lewdmanhwa.com/webtoons?genres=drama", script: "homecontent.js" },
        { title: "Romance", input: "https://lewdmanhwa.com/webtoons?genres=romance", script: "homecontent.js" },
        { title: "Mature", input: "https://lewdmanhwa.com/webtoons?genres=mature", script: "homecontent.js" },
        { title: "Yaoi", input: "https://lewdmanhwa.com/webtoons?genres=yaoi", script: "homecontent.js" },
        { title: "Josei", input: "https://lewdmanhwa.com/webtoons?genres=josei", script: "homecontent.js" },
        { title: "Fantasy", input: "https://lewdmanhwa.com/webtoons?genres=fantasy", script: "homecontent.js" },
        { title: "Comedy", input: "https://lewdmanhwa.com/webtoons?genres=comedy", script: "homecontent.js" }
    ]);
}
