// Helpers used by scripts via load('common.js'). Compatible with the vBook/jsoup API.
var LM_BASE = 'https://lewdmanhwa.com';

function lmClean(v) { return String(v || '').replace(/\s+/g, ' ').trim(); }
function lmAbs(raw, context) {
    var s = lmClean(raw).replace(/&amp;/g, '&');
    if (!s || /^(javascript:|data:|blob:|about:|#)/i.test(s)) return '';
    if (/^https?:\/\//i.test(s)) return s;
    if (s.indexOf('//') === 0) return 'https:' + s;
    if (s.charAt(0) === '/') return LM_BASE + s;
    var base = context || LM_BASE + '/';
    if (s.charAt(0) === '?') return base.replace(/\?.*$/, '') + s;
    return base.replace(/[?#].*$/, '').replace(/\/[^/]*$/, '/') + s;
}
function lmFirst(root, selector) {
    if (!root) return null;
    var elements = root.select(selector);
    return elements && elements.size() > 0 ? elements.get(0) : null;
}
function lmText(root, selector) {
    var el = lmFirst(root, selector);
    return el ? lmClean(el.text()) : '';
}
function lmAttr(root, selector, attr) {
    var el = lmFirst(root, selector);
    return el ? lmClean(el.attr(attr)) : '';
}
function lmImage(el, page) {
    if (!el) return '';
    var attrs = ['data-src', 'data-original', 'data-lazy-src', 'data-full-src', 'src'];
    for (var i = 0; i < attrs.length; i++) {
        var value = lmClean(el.attr(attrs[i]));
        if (value && !/^(data:|blob:|about:)/i.test(value)) return lmAbs(value, page);
    }
    var srcset = lmClean(el.attr('data-srcset') || el.attr('srcset'));
    return srcset ? lmAbs(srcset.split(',')[0].trim().split(/\s+/)[0], page) : '';
}
function lmGet(url) {
    var response = fetch(url, { headers: {
        'Accept': 'text/html,application/xhtml+xml',
        'Referer': LM_BASE + '/'
    }});
    if (!response.ok) throw new Error('HTTP ' + response.status + ': ' + url);
    return response.html();
}
function lmEsc(v) {
    return String(v).replace(/&/g, '&amp;').replace(/"/g, '&quot;')
        .replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function lmBookKey(value) {
    // Normalise title/slug keys without relying on optional JS runtime methods.
    return lmClean(value).toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]/g, '');
}
function lmCoverKey(url) {
    // E.g. /uploads/covers/the-lords-first-night-hd_thumb.webp
    // -> thelordsfirstnight, matching the /webtoon/the-lords-first-night slug.
    var raw = lmClean(url).replace(/%2f/ig, '/');
    var part = raw.split('?')[0].split('/').pop();
    return lmBookKey(part.replace(/\.(png|webp|jpe?g|avif)$/i, '')
        .replace(/(?:-hd)?_thumb$/i, '').replace(/-hd$/i, ''));
}
function lmBooks(doc, context) {
    // Cards on LewdManhwa have book links and cover <img> tags that may NOT
    // be children of the same <a>. Avoid parent(), selectFirst() etc.
    var anchors = doc.select('a[href*="/webtoon/"]');
    var books = [], indexes = {}, slugs = [];
    for (var i = 0; i < anchors.size(); i++) {
        var a = anchors.get(i), href = lmAbs(a.attr('href'), context);
        if (!/^https?:\/\/lewdmanhwa\.com\/webtoon\/[^\/?#]+\/?(?:\?.*)?$/i.test(href)) continue;
        var link = href.split('?')[0].replace(/\/$/, '');
        var slug = link.substring(link.lastIndexOf('/') + 1);
        var fallbackName = slug.replace(/-/g, ' ');
        var coverEl = lmFirst(a, 'img');
        var title = lmText(a, 'h3, h2') || lmClean(a.attr('title'));
        if (!title && coverEl) title = lmClean(coverEl.attr('alt'));
        if (!title) title = lmClean(a.text());
        if (!title) title = fallbackName;
        var cover = lmImage(coverEl, context);
        var description = lmText(a, '.text-sm, .text-xs, p') || '';
        if (Object.prototype.hasOwnProperty.call(indexes, link)) {
            var existing = books[indexes[link]];
            if (!existing.cover && cover) existing.cover = cover;
            if (lmBookKey(existing.name) === lmBookKey(fallbackName) &&
                lmBookKey(title) !== lmBookKey(fallbackName)) existing.name = title;
            if (!existing.description && description) existing.description = description;
            continue;
        }
        indexes[link] = books.length;
        slugs.push(slug);
        books.push({ name: title, link: link, cover: cover, description: description });
    }

    // Resolve covers independently. Image alt text and image filenames are
    // more reliable than DOM nesting for this website. A real cover URL has
    // been observed as /uploads/covers/<slug>[-hd]_thumb.webp.
    var images = doc.select('img');
    var coverCandidates = [];
    for (var j = 0; j < images.size(); j++) {
        var img = images.get(j);
        var src = lmImage(img, context);
        if (!src) continue;
        var alt = lmClean(img.attr('alt'));
        var altKey = lmBookKey(alt);
        var fileKey = lmCoverKey(src);
        var looksLikeCover = /(?:uploads[%\/]covers|_thumb\.|\/covers\/)/i.test(src);
        if (looksLikeCover) coverCandidates.push({ url: src, alt: alt });

        for (var k = 0; k < books.length; k++) {
            var book = books[k];
            var slugKey = lmBookKey(slugs[k]);
            var titleKey = lmBookKey(book.name);
            var altMatch = altKey && (altKey === slugKey || altKey === titleKey ||
                (altKey.length > 8 && slugKey.length > 8 && altKey.indexOf(slugKey) >= 0));
            var fileMatch = looksLikeCover && (fileKey === slugKey || fileKey === titleKey);
            if (altMatch || fileMatch) {
                if (!book.cover || looksLikeCover) book.cover = src;
                // Proper English title from cover alt is better than URL slug.
                if (altMatch && alt && lmBookKey(book.name) === slugKey) book.name = alt;
                break;
            }
        }
    }

    // Controlled fallback: only pair by order if cover images and catalogue
    // entries have the same count, so one unrelated image doesn't shift all.
    if (coverCandidates.length === books.length) {
        for (var n = 0; n < books.length; n++) {
            if (!books[n].cover) books[n].cover = coverCandidates[n].url;
            if (lmBookKey(books[n].name) === lmBookKey(slugs[n]) &&
                coverCandidates[n].alt) books[n].name = coverCandidates[n].alt;
        }
    }
    // Recent chapter tags are separate <a> nodes, not necessarily children of
    // the cover/title link. Match using book slug in the chapter URL, avoiding
    // DOM parent()/selectFirst() methods unsupported in some vBook runtimes.
    var chapterAnchors = doc.select('a[href*="/chapter/"]');
    for (var c = 0; c < chapterAnchors.size(); c++) {
        var ch = chapterAnchors.get(c);
        var chapterUrl = lmAbs(ch.attr('href'), context);
        var match = chapterUrl.match(/^https?:\/\/(?:www\.)?lewdmanhwa\.com\/webtoon\/([^\/?#]+)\/chapter\/([^\/?#]+)/i);
        if (!match) continue;
        var chapterSlug = match[1];
        var label = lmClean(ch.text());
        // Card links usually say "Ch. 39"; page numbers and view counts are not chapters.
        var chapterLabel = label.match(/\b(?:Ch(?:apter)?\.?\s*)(\d+(?:\.\d+)*)(?:\b|$)/i);
        var chapterNum = chapterLabel ? chapterLabel[1] : decodeURIComponent(match[2]);
        if (!/^\d+(?:\.\d+)*$/.test(chapterNum)) continue;
        for (var bi = 0; bi < books.length; bi++) {
            if (slugs[bi] === chapterSlug) {
                // First/latest visible chapter tag wins, matching the site catalogue.
                if (!/^Ch\.\s*\d/i.test(books[bi].description)) {
                    books[bi].description = 'Ch. ' + chapterNum;
                }
                break;
            }
        }
    }
    return books;
}
function lmNextPage(doc, number) {
    var next = number + 1;
    var anchors = doc.select('a[href*="page="]');
    for (var i = 0; i < anchors.size(); i++) {
        var a = anchors.get(i);
        var href = lmClean(a.attr('href'));
        if (new RegExp('[?&]page=' + next + '(?:&|$)').test(href)) return String(next);
    }
    // If no next link is visible in server-rendered HTML, pagination stops.
    return null;
}
