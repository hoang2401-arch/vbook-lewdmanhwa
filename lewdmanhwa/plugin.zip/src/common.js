// Helpers used by scripts via load('common.js'). Compatible with the vBook/jsoup API.
var LM_BASE = 'https://lewdmanhwa.com';

function lmClean(v) { return String(v || '').replace(/\s+/g, ' ').trim(); }
function lmAbs(raw, context) {
    var s = lmClean(raw).replace(/&amp;/g, '&');
    if (!s || /^(javascript:|data:|blob:|about:|#)/i.test(s)) return '';
    if (/^https?:\/\//i.test(s)) return s;
    if (s.indexOf('//') === 0) return 'https:' + s;
    if (s.charAt(0) === '/') return LM_BASE + s;
    var base = context || LM_BASE + '/';
    if (s.charAt(0) === '?') return base.replace(/\?.*$/, '') + s;
    return base.replace(/[?#].*$/, '').replace(/\/[^/]*$/, '/') + s;
}
function lmFirst(root, selector) {
    if (!root) return null;
    var elements = root.select(selector);
    return elements && elements.size() > 0 ? elements.get(0) : null;
}
function lmText(root, selector) {
    var el = lmFirst(root, selector);
    return el ? lmClean(el.text()) : '';
}
function lmAttr(root, selector, attr) {
    var el = lmFirst(root, selector);
    return el ? lmClean(el.attr(attr)) : '';
}
function lmImage(el, page) {
    if (!el) return '';
    var attrs = ['data-src', 'data-original', 'data-lazy-src', 'data-full-src', 'src'];
    for (var i = 0; i < attrs.length; i++) {
        var value = lmClean(el.attr(attrs[i]));
        if (value && !/^(data:|blob:|about:)/i.test(value)) return lmAbs(value, page);
    }
    var srcset = lmClean(el.attr('data-srcset') || el.attr('srcset'));
    return srcset ? lmAbs(srcset.split(',')[0].trim().split(/\s+/)[0], page) : '';
}
function lmGet(url) {
    var response = fetch(url, { headers: {
        'Accept': 'text/html,application/xhtml+xml',
        'Referer': LM_BASE + '/'
    }});
    if (!response.ok) throw new Error('HTTP ' + response.status + ': ' + url);
    return response.html();
}
function lmEsc(v) {
    return String(v).replace(/&/g, '&amp;').replace(/"/g, '&quot;')
        .replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function lmBooks(doc, context) {
    // The site's catalogue links follow /webtoon/<slug>.
    // IMPORTANT: vBook's runtime may NOT expose element.parent().
    // Read attributes and descendants of each <a> only, without DOM traversal.
    var anchors = doc.select('a[href*="/webtoon/"]');
    var books = [], indexes = {};
    for (var i = 0; i < anchors.size(); i++) {
        var a = anchors.get(i), href = lmAbs(a.attr('href'), context);
        if (!/^https?:\/\/lewdmanhwa\.com\/webtoon\/[^\/?#]+\/?(?:\?.*)?$/i.test(href)) continue;
        var link = href.split('?')[0].replace(/\/$/, '');
        var coverEl = lmFirst(a, 'img');
        var title = lmText(a, 'h3, h2') || lmClean(a.attr('title'));
        if (!title && coverEl) title = lmClean(coverEl.attr('alt'));
        if (!title) title = lmClean(a.text());
        var slug = link.substring(link.lastIndexOf('/') + 1).replace(/-/g, ' ');
        if (!title) title = slug;
        if (!title) continue;
        var cover = lmImage(coverEl, context);
        var description = lmText(a, '.text-sm, .text-xs, p') || '';

        // Cover and heading may use two separate <a> tags with the same href.
        // Merge their information instead of losing the second anchor.
        if (Object.prototype.hasOwnProperty.call(indexes, link)) {
            var existing = books[indexes[link]];
            if (!existing.cover && cover) existing.cover = cover;
            if (existing.name === slug && title !== slug) existing.name = title;
            if (!existing.description && description) existing.description = description;
            continue;
        }
        indexes[link] = books.length;
        books.push({ name: title, link: link, cover: cover, description: description });
    }
    return books;
}
function lmNextPage(doc, number) {
    var next = number + 1;
    var anchors = doc.select('a[href*="page="]');
    for (var i = 0; i < anchors.size(); i++) {
        var a = anchors.get(i);
        var href = lmClean(a.attr('href'));
        if (new RegExp('[?&]page=' + next + '(?:&|$)').test(href)) return String(next);
    }
    // If no next link is visible in server-rendered HTML, pagination stops.
    return null;
}
